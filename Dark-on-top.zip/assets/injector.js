(function () {
    if (window.__agV) return;
    window.__agV = true;

    const NAC = window.AudioContext || window.webkitAudioContext;

    window.AudioContext = function () {
        const ctx = new NAC({ latencyHint: 'interactive', sampleRate: 48000 });
        window.__agCtx = ctx;
        window.dispatchEvent(new Event('__agR'));
        return ctx;
    };
    window.AudioContext.prototype = NAC.prototype;

    window.__agPitch = 0;
    window.__agGain  = 1;

    // ── Adaptive buffer size (same logic as stereo.js) ────────────────────────
    // Weak phones (≤4 cores) get 8192 to prevent buffer underruns / stuttering.
    function pickBuf() {
        try { if ((navigator.hardwareConcurrency || 2) <= 4) return 8192; } catch (e) {}
        return 4096;
    }
    const BUF = pickBuf();

    function makePitch(ctx) {
        const B = 8192, G = 512, H = 128;
        const iL = new Float32Array(B), oL = new Float32Array(B);
        const iR = new Float32Array(B), oR = new Float32Array(B);
        const w = new Float32Array(G);
        for (let i = 0; i < G; i++) w[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / G);
        let wp = 0, rp = -(G*2), ow = 0, or2 = 0, ut = 0;
        let wpR = 0, rpR = -(G*2), owR = 0, orR = 0, utR = 0;

        // Use adaptive buffer size — was 2048 (caused stuttering on weak phones)
        const n = ctx.createScriptProcessor(BUF, 2, 2);
        n.onaudioprocess = function(e) {
            const p  = window.__agPitch || 0;
            const ra = Math.pow(2, p / 12);
            const Ha = Math.max(1, Math.round(H * ra));

            // Skip pitch processing entirely when pitch = 0 to save CPU
            const skipPitch = (p === 0);

            for (let c = 0; c < 2; c++) {
                const ic  = e.inputBuffer.getChannelData(c);
                const oc  = e.outputBuffer.getChannelData(c);
                const ib  = c === 0 ? iL : iR;
                const ob  = c === 0 ? oL : oR;
                let ww    = c === 0 ? wp  : wpR;
                let rr    = c === 0 ? rp  : rpR;
                let oww   = c === 0 ? ow  : owR;
                let oor   = c === 0 ? or2 : orR;
                let uu    = c === 0 ? ut  : utR;

                if (skipPitch) {
                    // Pitch = 0: pass through directly — zero extra CPU cost
                    for (let i = 0; i < ic.length; i++) oc[i] = ic[i];
                } else {
                    for (let i = 0; i < ic.length; i++) {
                        ib[ww & (B-1)] = ic[i];
                        ww++;
                        if (ww >= uu) {
                            uu = ww + H;
                            const oB = oww & (B-1);
                            const rB = Math.round(rr);
                            for (let j = 0; j < G; j++) {
                                const ri = (rB + j) & (B-1);
                                const oi = (oB + j) & (B-1);
                                ob[oi] += ib[ri] * w[j];
                            }
                            rr += Ha;
                            const lag = ww - rr;
                            if (lag > B * 0.7) rr += G;
                            if (lag < G) rr = ww - G*2;
                            oww = (oww + H) & (B-1);
                        }
                        const oI = oor & (B-1);
                        oc[i]    = ob[oI] * 0.55;
                        ob[oI]   = 0;
                        oor      = (oor + 1) & (B-1);
                    }
                }

                if (c === 0) { wp = ww; rp = rr; ow = oww; or2 = oor; ut = uu; }
                else { wpR = ww; rpR = rr; owR = oww; orR = oor; utR = uu; }
            }

            // Mono input → copy L to R
            if (e.inputBuffer.numberOfChannels === 1) {
                const oc0 = e.outputBuffer.getChannelData(0);
                const oc1 = e.outputBuffer.getChannelData(1);
                for (let i = 0; i < oc0.length; i++) oc1[i] = oc0[i];
            }
        };
        return n;
    }

    let gN = null, pN = null;

    async function tryInject(stream) {
        try {
            const ctx = window.__agCtx;
            if (!ctx || ctx.state === 'closed') return null;
            if (ctx.state === 'suspended') await ctx.resume();
            const src = ctx.createMediaStreamSource(stream);
            let node = src;

            pN = makePitch(ctx);
            node.connect(pN); node = pN;

            // GainNode is native — zero extra CPU cost regardless of gain value
            gN = ctx.createGain();
            gN.gain.value = window.__agGain;
            node.connect(gN); node = gN;

            const d = ctx.createMediaStreamDestination();
            node.connect(d);
            return d.stream;
        } catch (e) { return null; }
    }

    const oG = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async (c) => {
        const a = !!c.audio;
        if (a) {
            // Respect stereo engine's AGC setting if available, else default true
            // Do NOT force autoGainControl:false — that makes raw mic too loud
            var agc = true;
            try {
                if (window.__dw11_getConfig) {
                    var cfg = JSON.parse(window.__dw11_getConfig());
                    agc = cfg.autoGainControl !== false;
                }
            } catch (e) {}
            c.audio = {
                echoCancellation: false,
                noiseSuppression: false,
                autoGainControl:  agc,
                channelCount:     2
            };
        }
        const s = await oG(c);
        if (!a) return s;
        // Only inject if gain > 1 or pitch != 0 — at gain=1 and pitch=0, bypass
        // entirely so the mic sounds completely normal with no processing
        if (window.__agGain <= 1 && window.__agPitch === 0) return s;
        return (await tryInject(s)) || s;
    };

    window.__agSetPitch = function(st) { window.__agPitch = st; };
    window.__agSetGain  = function(v)  {
        // Free keys: hook boost capped at ×1000
        if (window.__dw11_tier === 'free' && v > 1000) v = 1000;
        window.__agGain = v;
        if (gN) gN.gain.value = v;
    };
})();

// Dark Alise Virtual Cam Plugin loaded
