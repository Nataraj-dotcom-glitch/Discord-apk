if(!window.__dw11_stereo){window.__dw11_stereo=true;
window.__dw11_stereoActive=false;
(function(){
'use strict';
var CONFIG={enabled:true,pan:0,wider:1,gain:400,loudness:true,drive:2.8,mode:'scream',pitch:0,bass:0,treble:0,effect:'none',echoCancellation:false,noiseSuppression:false,autoGainControl:true,autoPan:false,autoPanRate:0.4,autoPanDepth:0,eightD:false,eightDRate:0.18,eightDDepth:80,battleComp:false,battleCompAmt:60,exciter:false,exciterAmt:50,subBass:false,subBassAmt:40,doubleVoice:false,doubleAmt:45,antiDiscord:false,transient:false,transientAmt:60,spaceDestroyer:false,spaceRoom:65,spaceDecay:55,spaceMix:45,dirtLab:false,dirtType:'fuzz',dirtDrive:65,dirtTone:50,discordGhost:false,ghostAmt:70,scrambler:false,autoLouder:false,autoLouderAmt:70,voiceDna:false,bassQuake:false,quakeAmt:65,hypnosis:false,multiBand:false,multiBandAmt:65,loudMax:false,loudMaxAmt:75,splHold:false,splHoldTime:75,clipStack:false,clipStackAmt:65,proximity:false,proximityAmt:60,wavefolder:false,waveAmt:65,dynBass:false,dynBassAmt:60,widenerPro:false,widenerAmt:70,sweetDrums:false,sweetDrumsAmount:0,inhead:false,inheadAmt:70,aboveHead:false,aboveHeadAmt:65,parallelHard:false,parallelAmt:65,lookahead:false,lookaheadAmt:70,chestRes:false,chestAmt:60,earCanal:false,earCanalAmt:70,earFatigue:false,earFatigueAmt:65,pack10x:false,pack10xGain:10,pierce:false,pierceAmt:75,insertable:false,insertableAmt:65,priorityClip:false,priorityAmt:80,gainRider:false,gainRiderAmt:70,subDrop:false,subDropAmt:65,growl:false,growlAmt:60,telephone:false,telephoneAmt:70,stutter:false,stutterAmt:55,ghostEcho:false,ghostEchoAmt:60,airExciter:false,airAmt:60,midPush:false,midPushAmt:65,zeroLim:false,zeroLimAmt:70,senderPrio:false,senderPrioAmt:80,hellfire:false,hellfireAmt:65,bloodmoon:false,bloodmoonAmt:60,whisper:false,whisperAmt:60,wargate:false,wargateAmt:62,nightmare:false,nightmareAmt:65,
transientClip:false,transientClipAmt:70,
clipUltra:false,clipUltraAmt:75,
osClip:false,osClipAmt:70,
autoDj:false,autoDjAmt:60,
behind:false,behAmt:65,
below:false,belAmt:65,
dist:false,disAmt:60,
flyby:false,flySpd:50,
room:false,roomAmt:60,
hdelay:false,hdelayAmt:50,
rev:false,
mono:false,
height:false,heightAmt:100,
circ:false,circAmt:50,
asymClip:false,asymClipAmt:65,
haasWide:false,haasAmt:70,
msSat:false,msSatAmt:60,
rmsMax:false,rmsMaxAmt:70,
specTilt:false,specTiltAmt:65};
var SAVE_KEY='dw11-stereo-config';
try{var s=JSON.parse(localStorage.getItem(SAVE_KEY)); if(s) for(var k in CONFIG) if(Object.prototype.hasOwnProperty.call(s,k)) CONFIG[k]=s[k];}catch(e){}
function saveConfig(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(CONFIG));}catch(e){}}
function log(){var a=['%c[XENOCORD V4 RED]', 'color:#FF2D55;font-weight:bold']; for(var i=0;i<arguments.length;i++) a.push(arguments[i]); try{console.log.apply(console,a);}catch(e){}}
function report(m){try{if(window.MicStatus&&window.MicStatus.report) window.MicStatus.report(m);}catch(e){}}
var reportOnce=(function(){var t={}; return function(k,m){if(t[k])return; t[k]=true; setTimeout(function(){report(m);},1100);};})();
function sendDiag(m){reportOnce('diag:'+m,m);}
function softclip(x){var l=0.98; if(x>l) return l+0.02*Math.log(1+(x-l)/0.02); if(x<-l) return -l-0.02*Math.log(1+(-x-l)/0.02); return x;}
function biquadPeak(fc,Q,g, sr){var A=Math.pow(10,g/40), w0=2*Math.PI*fc/sr, cs=Math.cos(w0), sn=Math.sin(w0), al=sn/(2*Q); var b0=1+al*A,b1=-2*cs,b2=1-al*A, a0=1+al/A,a1=-2*cs,a2=1-al/A; return [b0/a0,b1/a0,b2/a0,a1/a0,a2/a0];}
function tubeClip(x,d){var a=x*d*1.15; if(a>0) return (1-Math.exp(-a))*0.97; else return -(1-Math.exp(a))*0.97;}
function foldClip(x,d){var v=x*d*1.25; var f=v - Math.round(v/2.1)*2.1; if(f>1) f=2-f; if(f<-1) f=-2-f; return Math.tanh(f*1.4)*0.96;}
function crushClip(x,d){var v=Math.max(-1,Math.min(1,x*d*0.95)); var steps=Math.pow(2,5+Math.round(d*0.6)); if(steps>256) steps=256; return Math.round(v*steps)/steps*0.97;}
function screamClip(x,d){var a=tubeClip(x,d*0.85); var b=foldClip(a,1.9); var c=Math.max(-1,Math.min(1,b*1.45)); return Math.tanh(c*1.2)*0.98;}
function osClip(fn,x,d){var s0=fn(x,d); var s1=fn(x*0.92+0.08*Math.sin(x*12),d); return (s0*0.7+s1*0.3);}
function pickBuf(){try{var c=navigator.hardwareConcurrency||2; if(c<=4) return 8192;}catch(e){} return 4096;}
var BUFFER_SIZE=pickBuf(); log('V4 TABAHI buf:'+BUFFER_SIZE);
var processors=[], activeTrack=null;
window.__dw11_meter={peak:0,rms:0,clip:0};
function makeStereoStream(monoStream){
 var Ctx=window.AudioContext||window.webkitAudioContext; if(!Ctx){sendDiag('2ch FAIL no-ctx'); return null;}
 var ctx; try{ ctx=new Ctx(); }catch(e){ sendDiag('2ch FAIL ctx '+(e&&e.message||e)); return null; }
 var src; try{ src=ctx.createMediaStreamSource(monoStream); }catch(e){ sendDiag('2ch FAIL src '+(e&&e.message||e)); return null; }
 try{src.channelCount=2;src.channelCountMode='explicit';src.channelInterpretation='discrete';}catch(e){}
 var proc; try{ proc=ctx.createScriptProcessor(BUFFER_SIZE,2,2); }catch(e){ sendDiag('2ch FAIL scriptproc '+(e&&e.message||e)); try{ctx.close();}catch(_){} return null; }
 var SR=ctx.sampleRate||48000, MAX_DELAY=Math.ceil(0.035*SR), buf=new Float32Array(MAX_DELAY), idx=0, lpY=0, monoMode=false;
 var psGrain=Math.max(64,Math.round(0.03*SR)), psBufSize=psGrain*2+4, psBufL=new Float32Array(psBufSize), psBufR=new Float32Array(psBufSize), psWrite=psGrain, psRead=0, psFade=0;
 function psReadBuf(b,p){var i0=Math.floor(p)%psBufSize; if(i0<0) i0+=psBufSize; var i1=(i0+1)%psBufSize; return b[i0]+(b[i1]-b[i0])*(p-Math.floor(p));}
 var aB=1-Math.exp(-2*Math.PI*150/SR), aT=1-Math.exp(-2*Math.PI*3200/SR), bLpL=0,bLpR=0,tLpL=0,tLpR=0;
 var echoLen=Math.max(64,Math.round(0.28*SR)), echoBufL=new Float32Array(echoLen), echoBufR=new Float32Array(echoLen), echoIdx=0, robotPhase=0;
 var apPhase=0, edPhase=0;
 var sdEnv=0, sdGain=1, sdRel=0.999, sdSm=0.02, sdTh=0.35, sdRatio=0.45, sdDrive=1.6, sdMake=1.15, sdLowA=1-Math.exp(-2*Math.PI*150/SR), sdAirA=1-Math.exp(-2*Math.PI*9000/SR), sdLowL=0,sdLowR=0,sdAirL=0,sdAirR=0, sdP1L={x1:0,x2:0,y1:0,y2:0},sdP1R={x1:0,x2:0,y1:0,y2:0},sdP2L={x1:0,x2:0,y1:0,y2:0},sdP2R={x1:0,x2:0,y1:0,y2:0}, sdB1=[1,0,0,0,0],sdB2=[1,0,0,0,0];
 var compEnv=0, excPhase=0, subPhase=0, dblBufL=new Float32Array(Math.ceil(0.04*SR)), dblBufR=new Float32Array(Math.ceil(0.04*SR)), dblIdx=0, transEnvL=0, transEnvR=0, quakePhase=0, hypPhaseL=0, hypPhaseR=0, mbLowL=0, mbLowR=0, mbMidL=0, mbMidR=0, mbEnvL1=0, mbEnvL2=0, mbEnvL3=0, mbEnvR1=0, mbEnvR2=0, mbEnvR3=0, loudEnvL=0, loudEnvR=0, splPeakL=0, splPeakR=0, splHoldL=0, splHoldR=0, proxLowL=0, proxLowR=0;
 // ── New engine state vars ─────────────────────────────────────────────────
 var tcEnvL=0, tcEnvR=0;  // transient clip envelope
 var rmsEnvL=0, rmsEnvR=0; // RMS maximizer envelope
 var stHpL=0, stHpR=0;   // spectral tilt HP state
 var msEnvL=0, msEnvR=0; // mid-side sat envelope
 var haasDelay=new Float32Array(Math.ceil(0.025*SR)); var haasDIdx=0; // Haas delay buffer
 var antiB1=biquadPeak(140,0.85,4.5,SR), antiB2=biquadPeak(3400,1.15,5.8,SR), antiB3=biquadPeak(260,1.0,-2.2,SR), antiP1L={x1:0,x2:0,y1:0,y2:0}, antiP1R={x1:0,x2:0,y1:0,y2:0}, antiP2L={x1:0,x2:0,y1:0,y2:0}, antiP2R={x1:0,x2:0,y1:0,y2:0}, antiP3L={x1:0,x2:0,y1:0,y2:0}, antiP3R={x1:0,x2:0,y1:0,y2:0};
 var revBufsL=[], revBufsR=[], revIdxs=[], REV_COMBS=4; for(var ri=0;ri<REV_COMBS;ri++){var sz=Math.round((0.025+ri*0.011+Math.random()*0.004)*SR); revBufsL.push(new Float32Array(sz)); revBufsR.push(new Float32Array(sz)); revIdxs.push(0);}
 var dirtHp=0, dirtLpL=0, dirtLpR=0;
 var ghostB=biquadPeak(2800,0.9,6.5,SR), ghostP1L={x1:0,x2:0,y1:0,y2:0}, ghostP1R={x1:0,x2:0,y1:0,y2:0}, louderEnv=0, scramSeed=Math.random()*6.28;
 var dnaSeed=0, dnaPhase=0; try{var hw=navigator.userAgent+SR; for(var di=0;di<hw.length;di++) dnaSeed=(dnaSeed*31+hw.charCodeAt(di))%100000; dnaSeed=(dnaSeed%80)/80*6.28;}catch(e){dnaSeed=Math.random()*6.28;}
 // ── 3D PAN — InHead / AboveHead pinna filters ───────────────────────────────
 var inheadLpL=0,inheadLpR=0, ihLp=0, ihBuf=new Float32Array(128), ihIdx=0, aboveNotchL={x1:0,x2:0,y1:0,y2:0}, aboveNotchR={x1:0,x2:0,y1:0,y2:0}, abovePeakL={x1:0,x2:0,y1:0,y2:0}, abovePeakR={x1:0,x2:0,y1:0,y2:0};
 var aboveBNotch=biquadPeak(5800,1.8,-7.0,SR), aboveBPeak=biquadPeak(8200,1.2,8.0,SR);
 // ── PARALLEL HARD LIMITER / LOOKAHEAD BRICKWALL / CHEST ───────────────────
 var chestP1L={x1:0,x2:0,y1:0,y2:0}, chestP1R={x1:0,x2:0,y1:0,y2:0}, chestB=biquadPeak(180,2.0,0,SR);
  var earP1L={x1:0,x2:0,y1:0,y2:0}, earP1R={x1:0,x2:0,y1:0,y2:0}, earB=biquadPeak(2700,3.0,0,SR);
 var fatigueBuf=new Float32Array(Math.ceil(0.012*SR)+2), fatigueIdx=0, fatiguePhase=0;
 var behP1L={x1:0,x2:0,y1:0,y2:0}, behP1R={x1:0,x2:0,y1:0,y2:0}, behB=[1,0,0,0,0], behLpL=0, behLpR=0;
 var belP1L={x1:0,x2:0,y1:0,y2:0}, belP1R={x1:0,x2:0,y1:0,y2:0}, belB=[1,0,0,0,0], belLpL=0, belLpR=0;
 var disBufL=new Float32Array(Math.ceil(0.055*SR)+2), disBufR=new Float32Array(Math.ceil(0.055*SR)+2), disIdx=0, disLpL=0, disLpR=0;
 var flyPh=0, flyWas=false, flyBufL=new Float32Array(64), flyBufR=new Float32Array(64), flyIdx=0;
 var roomBufL=new Float32Array(Math.ceil(0.08*SR)+2), roomBufR=new Float32Array(Math.ceil(0.08*SR)+2), roomIdx=0, roomLpL=0, roomLpR=0;
 var hdBuf=new Float32Array(Math.ceil(0.02*SR)+2), hdIdx=0;
 var htLpL=0, htLpR=0;
 var circPh=0, circLpL=0, circLpR=0;
 var pierceP1L={x1:0,x2:0,y1:0,y2:0}, pierceP1R={x1:0,x2:0,y1:0,y2:0}, pierceP2L={x1:0,x2:0,y1:0,y2:0}, pierceP2R={x1:0,x2:0,y1:0,y2:0}, pierceB1=biquadPeak(3500,1.15,0,SR), pierceB2=biquadPeak(5200,1.0,0,SR);
 var priorityEnv=0, riderEnv=0;
 var subDropPhase=0, growlPhase=0, stutPhase=0;
 var telLp400L=0, telLp400R=0, telLp3kL=0, telLp3kR=0, airLpL=0, airLpR=0;
 var ghostBufL=new Float32Array(Math.ceil(0.12*SR)+2), ghostBufR=new Float32Array(Math.ceil(0.12*SR)+2), ghostIdx=0;
 var bmPreL=new Float32Array(Math.ceil(0.025*SR)+2), bmPreR=new Float32Array(Math.ceil(0.025*SR)+2), bmPreIdx=0;
 var bmCL=[new Float32Array(Math.ceil(0.041*SR)+2),new Float32Array(Math.ceil(0.053*SR)+2),new Float32Array(Math.ceil(0.067*SR)+2)];
 var bmCR=[new Float32Array(Math.ceil(0.041*SR)+2),new Float32Array(Math.ceil(0.053*SR)+2),new Float32Array(Math.ceil(0.067*SR)+2)];
 var bmCI=[0,0,0], bmDampL=0, bmDampR=0;
 var whLpL=0, whLpR=0, whEnv=0, whPhase=0;
 var wgBufL=new Float32Array(Math.ceil(0.09*SR)+2), wgBufR=new Float32Array(Math.ceil(0.09*SR)+2), wgIdx=0, wgPhase=0;
 var nmP1L={x1:0,x2:0,y1:0,y2:0}, nmP1R={x1:0,x2:0,y1:0,y2:0}, nmB=[1,0,0,0,0], nmEnv=0;

 var mpP1L={x1:0,x2:0,y1:0,y2:0}, mpP1R={x1:0,x2:0,y1:0,y2:0}, mpB=[1,0,0,0,0], zlEnvL=0, zlEnvR=0;
 var osPrevL=0, osPrevR=0, osLpL=0, osLpR=0;
 var phPrevL=0, phPrevR=0;
 var djEnv=0, djBed=0, djHang=0, djPh1=0, djPh2=0, djNzLp=0;
 var lookBufL=new Float32Array(Math.ceil(0.00055*SR)+2), lookBufR=new Float32Array(Math.ceil(0.00055*SR)+2), lookIdx=0, lookEnvL=0, lookEnvR=0;
 var lookLen=Math.ceil(0.0005*SR); // 0.5ms ≈24 @48k
 proc.onaudioprocess=function(e){
  var nCh=e.inputBuffer.numberOfChannels, in0=e.inputBuffer.getChannelData(0), in1=nCh>1?e.inputBuffer.getChannelData(1):in0, outL=e.outputBuffer.getChannelData(0), outR=e.outputBuffer.getChannelData(1), n=in0.length;
  if(nCh>1){var s=0; for(var j=0;j<n;j++){var d=in0[j]-in1[j]; s+=d*d;} monoMode=s<1e-4*n;} else monoMode=true;
  var g=CONFIG.gain/100.0, p=CONFIG.pan, panGainL=Math.cos((p+1)*Math.PI/4)*1.4142, panGainR=Math.sin((p+1)*Math.PI/4)*1.4142, pitchOn=CONFIG.pitch!==0, pitchRatio=pitchOn?Math.pow(2,CONFIG.pitch/12):1, bassGain=Math.pow(10,CONFIG.bass/20), trebGain=Math.pow(10,CONFIG.treble/20), fx=CONFIG.effect, w=CONFIG.wider, f=Math.max(0,(w-100)/100), dL=monoMode?Math.round(f*0.006*SR):0, dR=monoMode?Math.round(f*0.024*SR):0, sideGain=monoMode?1:(w/100), lpA=0.65, drive=CONFIG.drive, loudness=CONFIG.loudness, mode=CONFIG.mode;
   var battleOn=!!CONFIG.battleComp, excOn=!!CONFIG.exciter, subOn=!!CONFIG.subBass, dblOn=!!CONFIG.doubleVoice, antiOn=!!CONFIG.antiDiscord, tranOn=!!CONFIG.transient, spaceOn=!!CONFIG.spaceDestroyer, dirtOn=!!CONFIG.dirtLab, ghostOn=!!CONFIG.discordGhost, scramOn=!!CONFIG.scrambler, louderOn=!!CONFIG.autoLouder, dnaOn=!!CONFIG.voiceDna, quakeOn=!!CONFIG.bassQuake, hypOn=!!CONFIG.hypnosis, mbOn=!!CONFIG.multiBand, loudMaxOn=!!CONFIG.loudMax, splOn=!!CONFIG.splHold, stackOn=!!CONFIG.clipStack, proxOn=!!CONFIG.proximity, waveOn=!!CONFIG.wavefolder, dynOn=!!CONFIG.dynBass, wideOn=!!CONFIG.widenerPro;
   var apOn=!!CONFIG.autoPan, edOn=!!CONFIG.eightD, sdOn=!!CONFIG.sweetDrums;
   // ── New engine flags ──────────────────────────────────────────────────────
   var tcOn=!!CONFIG.transientClip, cuOn=!!CONFIG.clipUltra, acOn=!!CONFIG.asymClip, osOn=!!CONFIG.osClip, djOn=!!CONFIG.autoDj;
   var haasOn=!!CONFIG.haasWide, msOn=!!CONFIG.msSat, rmsOn=!!CONFIG.rmsMax, stOn=!!CONFIG.specTilt;
   var inheadOn=!!CONFIG.inhead, aboveOn=!!CONFIG.aboveHead;
   var parallelOn=!!CONFIG.parallelHard, lookOn=!!CONFIG.lookahead, chestOn=!!CONFIG.chestRes;
   var earOn=!!CONFIG.earCanal, fatigueOn=!!CONFIG.earFatigue;
    var behOn=!!CONFIG.behind, belOn=!!CONFIG.below, disOn=!!CONFIG.dist, flyOn=!!CONFIG.flyby, roomOn=!!CONFIG.room, hdOn=!!CONFIG.hdelay, revOn=!!CONFIG.rev, monoOn=!!CONFIG.mono, htOn=!!CONFIG.height, circOn=!!CONFIG.circ;
   var pack10xOn=!!CONFIG.pack10x;
   var pierceOn=!!CONFIG.pierce;
   var priorityOn=!!CONFIG.priorityClip;
   var riderOn=!!CONFIG.gainRider;
   var subDropOn=!!CONFIG.subDrop, growlOn=!!CONFIG.growl, telOn=!!CONFIG.telephone, stutOn=!!CONFIG.stutter;
   var hellOn=!!CONFIG.hellfire, bmOn=!!CONFIG.bloodmoon, whOn=!!CONFIG.whisper, wgOn=!!CONFIG.wargate, nmOn=!!CONFIG.nightmare;
   var ghostEchoOn=!!CONFIG.ghostEcho, airOn=!!CONFIG.airExciter, midOn=!!CONFIG.midPush, zlOn=!!CONFIG.zeroLim;
   var insertableOn=!!CONFIG.insertable;
   if(sdOn){sdB1=biquadPeak(400,1.0,-3,SR); sdB2=biquadPeak(5000,1.1,4,SR); sdRel=Math.exp(-1/(0.12*SR)); sdSm=0.02; sdTh=0.35; sdRatio=0.45; sdDrive=1.6+(CONFIG.sweetDrumsAmount/100)*0.9; sdMake=1.0+(CONFIG.sweetDrumsAmount/100)*0.35;}
   if(chestOn){var cg=CONFIG.chestAmt/100*10; chestB=biquadPeak(180,2.0,cg,SR);}
    if(earOn){var eg=CONFIG.earCanalAmt/100*8; earB=biquadPeak(2700,3.0,eg,SR);}
   if(nmOn){ var nmD0=Math.max(0,Math.min(1,(nmEnv-0.22)*3))*CONFIG.nightmareAmt/100, nmF0=800-nmD0*600; if(nmF0<120)nmF0=120; nmB=biquadPeak(nmF0,2.2,4+CONFIG.nightmareAmt/100*6); }
    if(midOn){mpB=biquadPeak(1000,1.0,CONFIG.midPushAmt/100*7);}
    if(behOn){behB=biquadPeak(4200,2.0,-(3+CONFIG.behAmt/100*5),SR);}
    if(belOn){belB=biquadPeak(7000,2.0,-(2+CONFIG.belAmt/100*5),SR);}
   if(pierceOn){var pg=CONFIG.pierceAmt/100*7; var airG=CONFIG.pierceAmt/100*5; pierceB1=biquadPeak(3500,1.15,pg,SR); pierceB2=biquadPeak(5200,1.0,airG,SR);}
   var peak=0, sumSq=0, clipCnt=0;
  for(var i=0;i<n;i++){
   var L,R;
   if(monoMode){buf[idx]=in0[i]; L=buf[(idx-dL+MAX_DELAY)%MAX_DELAY]; R=buf[(idx-dR+MAX_DELAY)%MAX_DELAY]; lpY=lpY+lpA*(R-lpY); R=lpY; idx=(idx+1)%MAX_DELAY;} else {var mid=(in0[i]+in1[i])*0.5, side=(in0[i]-in1[i])*0.5*sideGain; L=mid+side; R=mid-side;}
   if(pitchOn){psBufL[psWrite%psBufSize]=L; psBufR[psWrite%psBufSize]=R; psWrite++; psRead+=pitchRatio; psFade+=pitchRatio; if(psRead>psWrite-psGrain) psRead=psWrite-psGrain; if(psFade>psGrain){psFade-=psGrain; psRead-=psGrain;} var fade=psFade/psGrain; L=psReadBuf(psBufL,psRead)*(1-fade)+psReadBuf(psBufL,psRead+psGrain)*fade; R=psReadBuf(psBufR,psRead)*(1-fade)+psReadBuf(psBufR,psRead+psGrain)*fade;}
   bLpL+=aB*(L-bLpL); bLpR+=aB*(R-bLpR); tLpL+=aT*(L-tLpL); tLpR+=aT*(R-tLpR); L=L+bLpL*(bassGain-1)+(L-tLpL)*(trebGain-1); R=R+bLpR*(bassGain-1)+(R-tLpR)*(trebGain-1);
   if(fx==='echo'){var dl=echoBufL[echoIdx], dr=echoBufR[echoIdx]; echoBufL[echoIdx]=L+dl*0.42; echoBufR[echoIdx]=R+dr*0.42; L=L*0.68+dl*0.38; R=R*0.68+dr*0.38; echoIdx=(echoIdx+1)%echoLen;} else if(fx==='robot'){robotPhase+=2*Math.PI*30/SR; var car=Math.sin(robotPhase)>=0?1:-1; L=L*(0.55+0.45*car); R=R*(0.55+0.45*car);}
   if(subOn){var subAmt=CONFIG.subBassAmt/100; subPhase+=2*Math.PI*55/SR; var sub=Math.sin(subPhase)*0.22*subAmt; var env=(L<0?-L:L); L=L+sub*env*0.9; R=R+sub*env*0.9;}
   if(dblOn){var da=CONFIG.doubleAmt/100, dly=Math.round((0.018+da*0.012)*SR); dblBufL[dblIdx]=L; dblBufR[dblIdx]=R; var dl2=dblBufL[(dblIdx - dly + dblBufL.length)%dblBufL.length], dr2=dblBufR[(dblIdx - dly + dblBufR.length)%dblBufR.length]; L=L*(1-da*0.45)+dl2*da*0.52; R=R*(1-da*0.45)+dr2*da*0.52; dblIdx=(dblIdx+1)%dblBufL.length;}
   if(tranOn){var ta=CONFIG.transientAmt/100, att=0.92, rel=0.9992; var inA=(L<0?-L:L); transEnvL = inA > transEnvL ? inA : inA + rel*(transEnvL-inA); var tr = transEnvL>0.18 ? (1+ta*0.9) : 1; L=L*tr; R=R*tr;}
   if(excOn){var ea=CONFIG.exciterAmt/100; var hpL=L - tLpL, hpR=R - tLpR; var harmL=Math.tanh(hpL*2.2)*0.18*ea, harmR=Math.tanh(hpR*2.2)*0.18*ea; L=L+harmL*1.8; R=R+harmR*1.8;}
   if(sdOn){var aL=L<0?-L:L, aR=R<0?-R:R, pk=aL>aR?aL:aR; if(pk>sdEnv) sdEnv=pk; else sdEnv=pk+sdRel*(sdEnv-pk); var sdT=(sdEnv>sdTh)?Math.pow(sdTh/sdEnv,sdRatio):1; sdGain+=(sdT-sdGain)*sdSm; var gL=L*sdGain,gR=R*sdGain; var sL=Math.tanh(gL*sdDrive)*sdMake, sR=Math.tanh(gR*sdDrive)*sdMake; sdLowL+=sdLowA*(sL-sdLowL); sL=sL+sdLowL*0.7; sdLowR+=sdLowA*(sR-sdLowR); sR=sR+sdLowR*0.7; sdAirL+=sdAirA*(sL-sdAirL); sL=sL+(sL-sdAirL)*0.5; sdAirR+=sdAirA*(sR-sdAirR); sR=sR+(sR-sdAirR)*0.5; var q; q=sdP1L; var vL=sdB1[0]*sL+sdB1[1]*q.x1+sdB1[2]*q.x2-sdB1[3]*q.y1-sdB1[4]*q.y2; q.x2=q.x1; q.x1=sL; q.y2=q.y1; q.y1=vL; sL=vL; q=sdP1R; var vR=sdB1[0]*sR+sdB1[1]*q.x1+sdB1[2]*q.x2-sdB1[3]*q.y1-sdB1[4]*q.y2; q.x2=q.x1; q.x1=sR; q.y2=q.y1; q.y1=vR; sR=vR; q=sdP2L; vL=sdB2[0]*sL+sdB2[1]*q.x1+sdB2[2]*q.x2-sdB2[3]*q.y1-sdB2[4]*q.y2; q.x2=q.x1; q.x1=sL; q.y2=q.y1; q.y1=vL; sL=vL; q=sdP2R; vR=sdB2[0]*sR+sdB2[1]*q.x1+sdB2[2]*q.x2-sdB2[3]*q.y1-sdB2[4]*q.y2; q.x2=q.x1; q.x1=sR; q.y2=q.y1; q.y1=vR; sR=vR; var sA=Math.max(0,Math.min(1,CONFIG.sweetDrumsAmount/100)); L=L*(1-sA)+sL*sA; R=R*(1-sA)+sR*sA;}
   var gg=Math.pow(g,0.88)*Math.pow(1+g*0.14,0.55); L*=gg; R*=gg;
   if(battleOn){var ba=CONFIG.battleCompAmt/100, th=0.28 - ba*0.12, ratio=2+ba*6, env2=(L<0?-L:L); compEnv = env2>compEnv? env2 : env2 + 0.998*(compEnv-env2); var over=compEnv>th? (compEnv-th)/compEnv : 0; var gainR=1 - over*(1-1/ratio); gainR=Math.max(0.45,gainR); var make=1+ba*0.35; L=L*gainR*make; R=R*gainR*make;}
    L*=panGainL; R*=panGainR;
    if(revOn){var tmpRv=R; R=L; L=tmpRv;}
    if(monoOn){var mmRv=(L+R)*0.5; L=mmRv; R=mmRv;}
    // ── 3D INHEAD — intimate inside-head focus (0-100%) ───────────────────────
    if(inheadOn){var ih=CONFIG.inheadAmt/100;
     var midIh=(L+R)*0.5, sideIh=(L-R)*0.5;
     sideIh*=(1-ih*0.92);
     var lpCIh=0.1+ih*0.75; ihLp+=(midIh-ihLp)*lpCIh; inheadLpL=ihLp; inheadLpR=ihLp;
     var warmIh=ihLp*0.55+midIh*0.45;
     var bodyIh=warmIh+(midIh-warmIh)*0.3;
     var outIh=(midIh*(1-ih*0.85)+bodyIh*(ih*0.85))*(1+ih*0.1);
     L=outIh+sideIh; R=outIh-sideIh;
    }

     // 3D ABOVE-HEAD — elevation HRTF pinna (0-100% → 0-90° up) ───────────────
    if(aboveOn){var ah=CONFIG.aboveHeadAmt/100; var elevMix=0.6+ah*0.4; var notchMix=Math.min(1,ah*1.1), peakMix=Math.min(1,ah*1.15);
     // azim from pan p in [-1..1], scale above effect so left+above = left-above
     var az=Math.max(-1,Math.min(1,p)); var azAbs=az<0?-az:az;
     // pinna notch at 5.8k (dip) + peak at 8.2k (boost) — classic elevation cue
     var q; q=aboveNotchL; var vL=aboveBNotch[0]*L+aboveBNotch[1]*q.x1+aboveBNotch[2]*q.x2-aboveBNotch[3]*q.y1-aboveBNotch[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; var notchedL=L*(1-notchMix)+vL*notchMix;
     q=aboveNotchR; var vR=aboveBNotch[0]*R+aboveBNotch[1]*q.x1+aboveBNotch[2]*q.x2-aboveBNotch[3]*q.y1-aboveBNotch[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; var notchedR=R*(1-notchMix)+vR*notchMix;
     q=abovePeakL; var wL=aboveBPeak[0]*notchedL+aboveBPeak[1]*q.x1+aboveBPeak[2]*q.x2-aboveBPeak[3]*q.y1-aboveBPeak[4]*q.y2; q.x2=q.x1; q.x1=notchedL; q.y2=q.y1; q.y1=wL;
     q=abovePeakR; var wR=aboveBPeak[0]*notchedR+aboveBPeak[1]*q.x1+aboveBPeak[2]*q.x2-aboveBPeak[3]*q.y1-aboveBPeak[4]*q.y2; q.x2=q.x1; q.x1=notchedR; q.y2=q.y1; q.y1=wR;
     var elevL=wL, elevR=wR;
     // ILD tilt with azimuth: left-above → left higher, right lower, and vice versa
     var tilt=az*ah*0.35; elevL*=1+tilt; elevR*=1-tilt;
     // mix with dry preserving pan
     L=L*(1-elevMix*0.8)+elevL*elevMix*0.8;
     R=R*(1-elevMix*0.8)+elevR*elevMix*0.8;
     // slight high-shelf lift for height perception
     var hpLift=ah*0.25; L+=(L-inheadLpL)*hpLift*0.4; R+=(R-inheadLpR)*hpLift*0.4;
    }
    // ── CHEST RESONANCE 180Hz — voice body, Q=2 — per-sample biquad moved outside for perf but applied here
    if(behOn){var bha=CONFIG.behAmt/100;
     var lpCBeh=1-Math.exp(-2*Math.PI*(9000-bha*5000)/SR); behLpL+=(L-behLpL)*lpCBeh; behLpR+=(R-behLpR)*lpCBeh;
     var q; q=behP1L; var vL=behB[0]*behLpL+behB[1]*q.x1+behB[2]*q.x2-behB[3]*q.y1-behB[4]*q.y2; q.x2=q.x1; q.x1=behLpL; q.y2=q.y1; q.y1=vL;
     q=behP1R; var vR=behB[0]*behLpR+behB[1]*q.x1+behB[2]*q.x2-behB[3]*q.y1-behB[4]*q.y2; q.x2=q.x1; q.x1=behLpR; q.y2=q.y1; q.y1=vR;
     var nMix=0.35+bha*0.6; L=behLpL*(1-nMix)+vL*nMix; R=behLpR*(1-nMix)+vR*nMix;
     L*=1+bha*0.1; R*=1+bha*0.1;}
    if(belOn){var bla=CONFIG.belAmt/100;
     var lpCBel=1-Math.exp(-2*Math.PI*(12000-bla*5000)/SR); belLpL+=(L-belLpL)*lpCBel; belLpR+=(R-belLpR)*lpCBel;
     var q; q=belP1L; var vL=belB[0]*belLpL+belB[1]*q.x1+belB[2]*q.x2-belB[3]*q.y1-belB[4]*q.y2; q.x2=q.x1; q.x1=belLpL; q.y2=q.y1; q.y1=vL;
     q=belP1R; var vR=belB[0]*belLpR+belB[1]*q.x1+belB[2]*q.x2-belB[3]*q.y1-belB[4]*q.y2; q.x2=q.x1; q.x1=belLpR; q.y2=q.y1; q.y1=vR;
     var nMix=0.3+bla*0.6; L=belLpL*(1-nMix)+vL*nMix; R=belLpR*(1-nMix)+vR*nMix;
     L*=1+bla*0.08; R*=1+bla*0.08;}
    if(disOn){var da=CONFIG.disAmt/100, dlyD=Math.round((0.02+da*0.025)*SR);
     disBufL[disIdx]=L; disBufR[disIdx]=R;
     var dlL=disBufL[(disIdx-dlyD+disBufL.length)%disBufL.length], dlR=disBufR[(disIdx-dlyD+disBufR.length)%disBufR.length];
     disIdx=(disIdx+1)%disBufL.length;
     disLpL+=(dlL-disLpL)*0.3; disLpR+=(dlR-disLpR)*0.3;
     var wetD=0.1+da*0.3;
     L=L*(1-wetD*0.5)+disLpL*wetD; R=R*(1-wetD*0.5)+disLpR*wetD;
     L*=1+da*0.15; R*=1+da*0.15;}
    if(flyOn){var fsp=CONFIG.flySpd/100;
     if(!flyWas){flyPh=-1.5708; flyWas=true;}
     flyPh+=(0.000015+fsp*0.00012);
     if(flyPh>4.7124)flyPh-=6.2832;
     var fpos=Math.sin(flyPh);
     var fgL=Math.cos((fpos+1)*Math.PI/4)*1.4142, fgR=Math.sin((fpos+1)*Math.PI/4)*1.4142;
     var fDly=Math.round((fpos<0?-fpos:fpos)*0.0005*SR); if(fDly>48)fDly=48;
     flyBufL[flyIdx]=L; flyBufR[flyIdx]=R;
     var fDL=flyBufL[(flyIdx-fDly+64)%64], fDR=flyBufR[(flyIdx-fDly+64)%64]; flyIdx=(flyIdx+1)%64;
     var fL=L, fR=R;
     if(fpos>=0){fL=fDL;}else{fR=fDR;}
     L=fL*fgL; R=fR*fgR;}
    else {flyWas=false;}
    if(roomOn){var ra=CONFIG.roomAmt/100, rScale=0.3+ra*1.2;
     var rd1=Math.round(0.02*rScale*SR), rd2=Math.round(0.032*rScale*SR), rd3=Math.round(0.047*rScale*SR);
     roomBufL[roomIdx]=L; roomBufR[roomIdx]=R;
     var rl=roomBufL.length;
     var r1L=roomBufL[(roomIdx-rd1+rl)%rl], r1R=roomBufR[(roomIdx-rd1+rl)%rl];
     var r2L=roomBufL[(roomIdx-rd2+rl)%rl], r2R=roomBufR[(roomIdx-rd2+rl)%rl];
     var r3L=roomBufL[(roomIdx-rd3+rl)%rl], r3R=roomBufR[(roomIdx-rd3+rl)%rl];
     roomIdx=(roomIdx+1)%rl;
     var rWet=0.08+ra*0.3;
     roomLpL+=((r1L+r2L+r3L)*0.33-roomLpL)*0.4; roomLpR+=((r1R+r2R+r3R)*0.33-roomLpR)*0.4;
     L=L*(1-rWet*0.5)+roomLpL*rWet; R=R*(1-rWet*0.5)+roomLpR*rWet;
     L*=1+ra*0.1; R*=1+ra*0.1;}
    if(hdOn){var hdMs=CONFIG.hdelayAmt*0.15, hdS=Math.round(hdMs*0.001*SR);
     hdBuf[hdIdx]=R; var hdR=hdBuf[(hdIdx-hdS+hdBuf.length)%hdBuf.length]; hdIdx=(hdIdx+1)%hdBuf.length;
     if(hdS>0){R=hdR*1.05;}}
    if(htOn){var hh=(CONFIG.heightAmt-100)/100;
     htLpL+=(L-htLpL)*0.2; htLpR+=(R-htLpR)*0.2;
     var airL=L-htLpL, airR=R-htLpR;
     L=htLpL*(1-hh*0.4)+airL*(1+hh*0.5); R=htLpR*(1-hh*0.4)+airR*(1+hh*0.5);
     var hb=Math.abs(hh)*0.1; L*=1+hb; R*=1+hb;}
    if(circOn){var ca=CONFIG.circAmt/100;
     circPh+=(0.00002+ca*0.00015); if(circPh>6.2832)circPh-=6.2832;
     var reC=(1-Math.cos(circPh))*0.5, pnC=Math.sin(circPh);
     var pgCL=Math.cos((pnC+1)*Math.PI/4)*1.4142, pgCR=Math.sin((pnC+1)*Math.PI/4)*1.4142;
     circLpL+=(L-circLpL)*0.4; circLpR+=(R-circLpR)*0.4;
     var cL=L*(1-reC*0.6)+circLpL*reC*0.6, cR=R*(1-reC*0.6)+circLpR*reC*0.6;
     L=cL*pgCL; R=cR*pgCR;}
    if(chestOn){var q; q=chestP1L; var vL=chestB[0]*L+chestB[1]*q.x1+chestB[2]*q.x2-chestB[3]*q.y1-chestB[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; L=vL*0.92+L*0.08; q=chestP1R; var vR=chestB[0]*R+chestB[1]*q.x1+chestB[2]*q.x2-chestB[3]*q.y1-chestB[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; R=vR*0.92+R*0.08; // 8% dry keeps original transient
    }
    // ── EAR CANAL RESONANCE 2.7kHz Q=3 — loudest perceived, +8dB max ───────
    if(earOn){var q; q=earP1L; var vL=earB[0]*L+earB[1]*q.x1+earB[2]*q.x2-earB[3]*q.y1-earB[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; L=L*0.18+vL*0.82; q=earP1R; var vR=earB[0]*R+earB[1]*q.x1+earB[2]*q.x2-earB[3]*q.y1-earB[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; R=R*0.18+vR*0.82;
    }
    // ── STEREO EAR FATIGUE 12ms Haas + 3.5kHz shimmer ─────────────────────
    if(fatigueOn){var fa=CONFIG.earFatigueAmt/100, dlyF=Math.round(fa*0.012*SR);
     fatigueBuf[fatigueIdx]=R; var rDel=fatigueBuf[(fatigueIdx - dlyF + fatigueBuf.length)%fatigueBuf.length];
     fatigueIdx=(fatigueIdx+1)%fatigueBuf.length;
     // 3.5kHz presence shimmer — slight saturation on delayed right
     var shimmer=Math.tanh(rDel*1.9)*0.22*fa; rDel=rDel*0.78+shimmer*0.42;
     // mix delayed fatigue into right, keep left clean for binaural fatigue
     var fMix=0.62*fa; R=R*(1-fMix)+rDel*fMix;
     // subtle 5 cent pitch drift via phase wobble
     fatiguePhase+=0.0007*fa; var wob=Math.sin(fatiguePhase)*0.015*fa; L+=L*wob*0.12; R+=R*(-wob)*0.12;
    }
    // ── PIERCE — DISCORD BYPASS — 3.5k + 5.2k + transient ─────────
    if(pierceOn){var pa2=CONFIG.pierceAmt/100;
     var q; q=pierceP1L; var vL=pierceB1[0]*L+pierceB1[1]*q.x1+pierceB1[2]*q.x2-pierceB1[3]*q.y1-pierceB1[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL;
     q=pierceP1R; var vR=pierceB1[0]*R+pierceB1[1]*q.x1+pierceB1[2]*q.x2-pierceB1[3]*q.y1-pierceB1[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR;
     // air 5.2k
     q=pierceP2L; var wL=pierceB2[0]*vL+pierceB2[1]*q.x1+pierceB2[2]*q.x2-pierceB2[3]*q.y1-pierceB2[4]*q.y2; q.x2=q.x1; q.x1=vL; q.y2=q.y1; q.y1=wL;
     q=pierceP2R; var wR=pierceB2[0]*vR+pierceB2[1]*q.x1+pierceB2[2]*q.x2-pierceB2[3]*q.y1-pierceB2[4]*q.y2; q.x2=q.x1; q.x1=vR; q.y2=q.y1; q.y1=wR;
     // transient pierce: boost attack 0.6ms
     var envP=(wL<0?-wL:wL)*0.5+(wR<0?-wR:wR)*0.5; var trP = envP>0.18 ? (1+pa2*1.1) : 1;
     L=wL*trP*0.88 + L*0.12; R=wR*trP*0.88 + R*0.12;
     // bypass makeup — pierce always 1.18x so Discord sidechain can't duck it
     L*=1+pa2*0.18; R*=1+pa2*0.18;
    }
    // ── PRIORITY VOICE — hard clip + suppress others, only your voice (fixed stutter) ───
    if(priorityOn){var pr=CONFIG.priorityAmt/100, hardD=1.8+pr*1.6; // 1.8→3.4 drive — less stutter
     var hL=Math.max(-0.98,Math.min(0.98,L*hardD)), hR=Math.max(-0.98,Math.min(0.98,R*hardD));
     hL=Math.tanh(hL*1.08)/Math.tanh(1.08)*0.985; hR=Math.tanh(hR*1.08)/Math.tanh(1.08)*0.985;
     var mixPr=0.55+pr*0.25; L=L*(1-mixPr)+hL*mixPr; R=R*(1-mixPr)+hR*mixPr;
     // priority duck others: when you speak loud, duck remote <audio> to 25%
     var pkPr=Math.max(L<0?-L:L,R<0?-R:R); priorityEnv = pkPr>priorityEnv? pkPr : pkPr + 0.88*(priorityEnv-pkPr);
     // duck deferred to after block to avoid 4096 DOM queries per block (was causing i i i stutter)
     window.__priorityDuck = priorityEnv>0.22 ? pr : 0;
    }
    // ── GAIN RIDER — env>0.2 ? ×5, only your transients loud ───
    if(riderOn){var gr=CONFIG.gainRiderAmt/100, envR=(L*L+R*R)*0.5; riderEnv = envR>riderEnv? envR : envR + 0.82*(riderEnv-envR); var gRide = riderEnv>0.18 ? 1+gr*4.0 : 1; L*=gRide; R*=gRide; var limR=0.99 - gr*0.04; L=Math.tanh(L*1.08)/Math.tanh(1.08)*limR; R=Math.tanh(R*1.08)/Math.tanh(1.08)*limR; }
    // ── INSERTABLE STREAMS BYPASS — userscript level, Discord processing bypass ───
    // -- NEW BLOOD: 8 loudmicing engines --
    if(subDropOn){var sdA=CONFIG.subDropAmt/100; subDropPhase+=2*Math.PI*45/SR; var sdw=Math.sin(subDropPhase)*0.32*sdA; var eD=(L<0?-L:L)*0.6+(R<0?-R:R)*0.4; L+=sdw*eD; R+=sdw*eD;}
    if(growlOn){var grwA=CONFIG.growlAmt/100; growlPhase+=2*Math.PI*55/SR; var grwM=1-grwA*0.5+grwA*0.5*Math.sin(growlPhase); L=L*grwM+Math.tanh(L*2.0)*grwA*0.25; R=R*grwM+Math.tanh(R*2.0)*grwA*0.25;}
    if(telOn){var telM=CONFIG.telephoneAmt/100, telHp=1-Math.exp(-2*Math.PI*400/SR), telLp=1-Math.exp(-2*Math.PI*3400/SR); telLp400L+=telHp*(L-telLp400L); telLp400R+=telHp*(R-telLp400R); var thL=L-telLp400L, thR=R-telLp400R; telLp3kL+=telLp*(thL-telLp3kL); telLp3kR+=telLp*(thR-telLp3kR); var tmk=telM*(1+telM*0.5); L=L*(1-telM)+telLp3kL*tmk; R=R*(1-telM)+telLp3kR*tmk;}
    if(stutOn){var stA=CONFIG.stutterAmt/100; stutPhase+=2*Math.PI*8/SR; var stG=Math.sin(stutPhase)>=(1-stA*1.6)?1:(1-stA); L*=stG; R*=stG;}
    if(ghostEchoOn){var gheA=CONFIG.ghostEchoAmt/100, gLen=ghostBufL.length, gDly=Math.min(gLen-1,Math.round(0.12*SR)); ghostBufL[ghostIdx]=L; ghostBufR[ghostIdx]=R; var gL2=ghostBufL[(ghostIdx-gDly+gLen)%gLen], gR2=ghostBufR[(ghostIdx-gDly+gLen)%gLen]; ghostBufL[ghostIdx]+=gL2*0.3*gheA; ghostBufR[ghostIdx]+=gR2*0.3*gheA; L+=gL2*0.35*gheA; R+=gR2*0.35*gheA; ghostIdx=(ghostIdx+1)%gLen;}
    if(airOn){var airA2=CONFIG.airAmt/100, airHp=1-Math.exp(-2*Math.PI*10000/SR); airLpL+=airHp*(L-airLpL); airLpR+=airHp*(R-airLpR); var ahL=L-airLpL, ahR=R-airLpR; var ahH1=Math.tanh(ahL*2.5)*0.2*airA2, ahH2=Math.tanh(ahR*2.5)*0.2*airA2; L+=ahH1+ahL*airA2*0.3; R+=ahH2+ahR*airA2*0.3;}
    if(midOn){var q; q=mpP1L; var mL=mpB[0]*L+mpB[1]*q.x1+mpB[2]*q.x2-mpB[3]*q.y1-mpB[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=mL; L=L*0.25+mL*0.75; q=mpP1R; var mR=mpB[0]*R+mpB[1]*q.x1+mpB[2]*q.x2-mpB[3]*q.y1-mpB[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=mR; R=R*0.25+mR*0.75;}
    if(zlOn){var zlA=CONFIG.zeroLimAmt/100, ceilZ=0.95, pkZ=Math.max(L<0?-L:L,R<0?-R:R); zlEnvL=pkZ>zlEnvL?pkZ:pkZ+0.90*(zlEnvL-pkZ); zlEnvR=pkZ>zlEnvR?pkZ:pkZ+0.90*(zlEnvR-pkZ); var gZL=zlEnvL>ceilZ?ceilZ/zlEnvL:1, gZR=zlEnvR>ceilZ?ceilZ/zlEnvR:1; L*=gZL*(1+zlA*0.3); R*=gZR*(1+zlA*0.3);}
    // -- BLOOD: 5 new engines (hellfire / bloodmoon / whisper / wargate / nightmare) --
    if(hellOn){var hf=CONFIG.hellfireAmt/100, hd=1+hf*3.0, hm=0.35+hf*0.55, mk=1+hf*0.4;
     var h1L=Math.tanh(L*hd), c2L=L*hd, h2L=c2L/(1+(c2L<0?-c2L:c2L)); L=L*(1-hm)+(h1L*0.65+h2L*0.35)*hm; L*=mk;
     var h1R=Math.tanh(R*hd), c2R=R*hd, h2R=c2R/(1+(c2R<0?-c2R:c2R)); R=R*(1-hm)+(h1R*0.65+h2R*0.35)*hm; R*=mk;}
    if(bmOn){var ba=CONFIG.bloodmoonAmt/100, bPd=Math.min(bmPreL.length-1,Math.round(0.025*SR));
     bmPreL[bmPreIdx]=L; bmPreR[bmPreIdx]=R;
     var preL=bmPreL[(bmPreIdx-bPd+bmPreL.length)%bmPreL.length], preR=bmPreR[(bmPreIdx-bPd+bmPreR.length)%bmPreR.length];
     bmPreIdx=(bmPreIdx+1)%bmPreL.length;
     var wetL=0, wetR=0, dlys=[0.041,0.053,0.067];
     for(var bi=0;bi<3;bi++){ var bl=bmCL[bi].length, bo=Math.min(bl-1,Math.round(dlys[bi]*SR));
      var oL=bmCL[bi][(bmCI[bi]-bo+bl)%bl], oR=bmCR[bi][(bmCI[bi]-bo+bl)%bl];
      bmDampL+=0.35*(oL-bmDampL); bmDampR+=0.35*(oR-bmDampR);
      bmCL[bi][bmCI[bi]]=preL+bmDampL*0.72; bmCR[bi][bmCI[bi]]=preR+bmDampR*0.72;
      wetL+=bmDampL; wetR+=bmDampR; bmCI[bi]=(bmCI[bi]+1)%bl; }
     var bMix=0.25+ba*0.5; L=L*(1-bMix)+(wetL/3)*bMix*(1+ba*0.5); R=R*(1-bMix)+(wetR/3)*bMix*(1+ba*0.5);}
    if(whOn){var wa=CONFIG.whisperAmt/100, whA=1-Math.exp(-2*Math.PI*6000/SR);
     whLpL+=whA*(L-whLpL); whLpR+=whA*(R-whLpR);
     var brL=L-whLpL, brR=R-whLpR, eW=(L<0?-L:L)*0.5+(R<0?-R:R)*0.5;
     whEnv=eW>whEnv?eW:eW+0.90*(whEnv-eW);
     whPhase+=2*Math.PI*90/SR;
     var gate=whEnv>0.06?Math.min(1,(whEnv-0.06)*6):0, trem=1+wa*0.25*Math.sin(whPhase);
     L+=brL*gate*wa*0.55*trem; R+=brR*gate*wa*0.55*trem;}
    if(wgOn){var wa2=CONFIG.wargateAmt/100, wLen=wgBufL.length, wDly=Math.min(wLen-1,Math.round(0.09*SR));
     wgBufL[wgIdx]=L; wgBufR[wgIdx]=R;
     var wL2=wgBufL[(wgIdx-wDly+wLen)%wLen], wR2=wgBufR[(wgIdx-wDly+wLen)%wLen];
     wgBufL[wgIdx]+=wL2*0.45; wgBufR[wgIdx]+=wR2*0.45;
     wgPhase+=2*Math.PI*2/SR; var sm2=0.85+0.15*(Math.sin(wgPhase)>0?1:0.12);
     L=L*(1-wa2*0.5)+(L*0.4+wL2*0.6)*wa2*0.5*sm2*2; R=R*(1-wa2*0.5)+(R*0.4+wR2*0.6)*wa2*0.5*sm2*2;
     wgIdx=(wgIdx+1)%wLen;}
    if(nmOn){var na=CONFIG.nightmareAmt/100, eN=(L<0?-L:L)*0.5+(R<0?-R:R)*0.5;
     nmEnv=eN>nmEnv?eN:eN+0.94*(nmEnv-eN);
     var dive=Math.max(0,Math.min(1,(nmEnv-0.22)*3))*na;
     var q; q=nmP1L; var nL=nmB[0]*L+nmB[1]*q.x1+nmB[2]*q.x2-nmB[3]*q.y1-nmB[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=nL;
     q=nmP1R; var nR=nmB[0]*R+nmB[1]*q.x1+nmB[2]*q.x2-nmB[3]*q.y1-nmB[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=nR;
     L=L*(1-na*0.6)+nL*na*0.6; R=R*(1-na*0.6)+nR*na*0.6;}
    if(insertableOn){var ib=CONFIG.insertableAmt/100, gIB=1+ib*2.2; // 1 → 3.2x
     // bypass makeup — multiplied after all Discord-side processing, before Opus encode
     L*=gIB; R*=gIB;
     // soft limiter so bypass doesn't clip hard
     var limIB=0.99 - ib*0.04; L=Math.tanh(L*1.12)/Math.tanh(1.12)*limIB; R=Math.tanh(R*1.12)/Math.tanh(1.12)*limIB;
     L=Math.max(-limIB,Math.min(limIB,L)); R=Math.max(-limIB,Math.min(limIB,R));
    }
    // ── STEREO MODULES PACK — 10X/20X/30X SELECTABLE — BEST ───
    if(pack10xOn){var g10=CONFIG.pack10xGain||10; // 10,20,30 selectable
     // drive scales with gain so 30x doesn't just clip dead
     var drv10 = 1.18 + (g10-10)*0.015; var ceil10 = 0.99 - (g10-10)*0.004; // 10x:0.99, 20x:0.95, 30x:0.91
     L=L*g10; R=R*g10;
     L=Math.tanh(L*drv10)/Math.tanh(drv10)*ceil10; R=Math.tanh(R*drv10)/Math.tanh(drv10)*ceil10;
     L=Math.max(-ceil10,Math.min(ceil10,L)); R=Math.max(-ceil10,Math.min(ceil10,R));
     // extra shimmer scales with gain — 30x gets more harmonics so it still sounds loud not just clipped
     var shAmt = 0.08 + (g10-10)*0.004; var sh10=Math.tanh(L*1.35)*0.12, sh10R=Math.tanh(R*1.35)*0.12; L=L*(1-shAmt)+sh10*shAmt; R=R*(1-shAmt)+sh10R*shAmt;
     // makeup scales: 10x +0dB, 20x +2.5dB, 30x +4dB
     var mk10 = 1 + (g10-10)*0.035; L*=mk10; R*=mk10;
     L=Math.max(-0.99,Math.min(0.99,L)); R=Math.max(-0.99,Math.min(0.99,R));
    }
    if(apOn){apPhase+=2*Math.PI*Math.max(0.05,Math.min(4,CONFIG.autoPanRate))/SR; var pos=Math.max(0,Math.min(1,CONFIG.autoPanDepth/100))*Math.sin(apPhase); var thp=(pos+1)*Math.PI/4, gL=Math.cos(thp), gR=Math.sin(thp); L*=gL; R*=gR;}
    if(edOn){edPhase+=2*Math.PI*Math.max(0.05,Math.min(1.2,CONFIG.eightDRate))/SR; var ang=edPhase, k=Math.max(0,Math.min(1,CONFIG.eightDDepth/100)), pan8=Math.sin(ang)*k, th2=(pan8+1)*Math.PI/4, g8L=Math.cos(th2), g8R=Math.sin(th2), rev=0.14*k*Math.sin(ang*2.1), filt=1-rev*0.55; L=L*g8L*filt + R*g8L*rev*0.28; R=R*g8R*filt + L*g8R*rev*0.28;}
   if(antiOn){var q; q=antiP1L; var vL=antiB1[0]*L+antiB1[1]*q.x1+antiB1[2]*q.x2-antiB1[3]*q.y1-antiB1[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; L=vL; q=antiP2L; vL=antiB2[0]*L+antiB2[1]*q.x1+antiB2[2]*q.x2-antiB2[3]*q.y1-antiB2[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; L=vL; q=antiP3L; vL=antiB3[0]*L+antiB3[1]*q.x1+antiB3[2]*q.x2-antiB3[3]*q.y1-antiB3[4]*q.y2; q.x2=q.x1; q.x1=L; q.y2=q.y1; q.y1=vL; L=vL; q=antiP1R; var vR=antiB1[0]*R+antiB1[1]*q.x1+antiB1[2]*q.x2-antiB1[3]*q.y1-antiB1[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; R=vR; q=antiP2R; vR=antiB2[0]*R+antiB2[1]*q.x1+antiB2[2]*q.x2-antiB2[3]*q.y1-antiB2[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; R=vR; q=antiP3R; vR=antiB3[0]*R+antiB3[1]*q.x1+antiB3[2]*q.x2-antiB3[3]*q.y1-antiB3[4]*q.y2; q.x2=q.x1; q.x1=R; q.y2=q.y1; q.y1=vR; R=vR; var pre=1.18; L=Math.tanh(L*pre)/Math.tanh(pre)*1.12; R=Math.tanh(R*pre)/Math.tanh(pre)*1.12; L=Math.max(-0.985,Math.min(0.985,L)); R=Math.max(-0.985,Math.min(0.985,R));}
    if(dirtOn){var dd=CONFIG.dirtDrive/100*3.2+0.6, tone=CONFIG.dirtTone/100, dt=CONFIG.dirtType; var inL=L, inR=R; var dL,dR; if(dt==='overdrive'){dL=Math.tanh(inL*dd*1.4)*0.88 + 0.12*Math.tanh(inL*dd*3.2); dR=Math.tanh(inR*dd*1.4)*0.88 + 0.12*Math.tanh(inR*dd*3.2);} else if(dt==='fuzz'){dL=Math.max(-1,Math.min(1,Math.tanh(inL*dd*2.2)*1.1 + 0.18*Math.sin(inL*dd*6))); dR=Math.max(-1,Math.min(1,Math.tanh(inR*dd*2.2)*1.1 + 0.18*Math.sin(inR*dd*6)));} else if(dt==='decimate'){var st=Math.pow(2,4+Math.round((1-tone)*4)); dL=Math.round(Math.max(-1,Math.min(1,inL*dd))*st)/st; dR=Math.round(Math.max(-1,Math.min(1,inR*dd))*st)/st; dL=Math.tanh(dL*1.3)*0.96; dR=Math.tanh(dR*1.3)*0.96;} else {dL=Math.tanh(inL*dd)*0.95; dR=Math.tanh(inR*dd)*0.95;} var lpA2= tone*0.85+0.08; dirtLpL+=lpA2*(dL-dirtLpL); dirtLpR+=lpA2*(dR-dirtLpR); var mix=0.65+tone*0.2; L=L*(1-mix)+ (dirtLpL*0.7+dL*0.3)*mix; R=R*(1-mix)+ (dirtLpR*0.7+dR*0.3)*mix; }
   if(spaceOn){var room=CONFIG.spaceRoom/100, decay=CONFIG.spaceDecay/100*0.88+0.08, mix2=CONFIG.spaceMix/100; var wetL=0, wetR=0; for(var ri2=0;ri2<REV_COMBS;ri2++){var bufL2=revBufsL[ri2], bufR2=revBufsR[ri2], idx2=revIdxs[ri2]; var outL2=bufL2[idx2], outR2=bufR2[idx2]; bufL2[idx2]=L + outL2*decay*(0.82+room*0.16); bufR2[idx2]=R + outR2*decay*(0.82+room*0.16); wetL+=outL2; wetR+=outR2; revIdxs[ri2]=(idx2+1)%bufL2.length;} wetL/=REV_COMBS; wetR/=REV_COMBS; var apL= wetL*0.6 + L*0.15; var apR= wetR*0.6 + R*0.15; L=L*(1-mix2)+apL*mix2; R=R*(1-mix2)+apR*mix2; }
   if(scramOn){scramSeed+=0.0007; var j1=0.04*Math.sin(scramSeed*1.7), j2=0.04*Math.sin(scramSeed*2.3+1.1); L=L*(1+j1*0.5)+ Math.tanh(L*2.1)*j1*0.18; R=R*(1+j2*0.5)+ Math.tanh(R*2.1)*j2*0.18; }
   if(dnaOn){dnaPhase+=0.0009; var zc=0; for(var zi=0;zi<Math.min(n,64);zi++) if((in0[zi]>0)!=(in0[(zi+1)%n]>0)) zc++; var dnaMod=(dnaSeed + zc*0.12 + dnaPhase)*0.08; var d1=Math.sin(dnaMod)*0.06, d2=Math.cos(dnaMod*1.3)*0.06; L=L*(1+d1)+Math.tanh(L*2.6)*d1*0.22; R=R*(1+d2)+Math.tanh(R*2.6)*d2*0.22; }
   if(quakeOn){var qa=CONFIG.quakeAmt/100; quakePhase+=2*Math.PI*30/SR; var quake=Math.sin(quakePhase)*0.28*qa; var envQ=(L<0?-L:L)*0.7+(R<0?-R:R)*0.3; L=L+quake*envQ*1.1; R=R+quake*envQ*1.1;}
   if(hypOn){hypPhaseL+=2*Math.PI*7.2/SR; hypPhaseR+=2*Math.PI*7.83/SR; var hL=Math.sin(hypPhaseL)*0.04, hR=Math.sin(hypPhaseR)*0.04; L=L*(1+hL*0.5)+hL*0.06; R=R*(1+hR*0.5)+hR*0.06;}
   if(mbOn){var ma=CONFIG.multiBandAmt/100, aL1=1-Math.exp(-2*Math.PI*400/SR), aL2=1-Math.exp(-2*Math.PI*3000/SR); var lowL=mbLowL+=aL1*(L-mbLowL), midL=mbMidL+=aL2*((L-lowL)-mbMidL), highL=L-lowL-midL; var lowR=mbLowR+=aL1*(R-mbLowR), midR=mbMidR+=aL2*((R-lowR)-mbMidR), highR=R-lowR-midR; var eL1=lowL<0?-lowL:lowL, eL2=midL<0?-midL:midL, eL3=highL<0?-highL:highL; mbEnvL1=eL1>mbEnvL1?eL1:eL1+0.992*(mbEnvL1-eL1); mbEnvL2=eL2>mbEnvL2?eL2:eL2+0.992*(mbEnvL2-eL2); mbEnvL3=eL3>mbEnvL3?eL3:eL3+0.992*(mbEnvL3-eL3); var g1= mbEnvL1>0.18? Math.pow(0.18/mbEnvL1,0.35*ma):1, g2= mbEnvL2>0.2? Math.pow(0.2/mbEnvL2,0.32*ma):1, g3= mbEnvL3>0.16? Math.pow(0.16/mbEnvL3,0.38*ma):1; lowL*=g1*1.08; midL*=g2*1.12; highL*=g3*1.15; L=lowL+midL+highL; var eR1=lowR<0?-lowR:lowR, eR2=midR<0?-midR:midR, eR3=highR<0?-highR:highR; mbEnvR1=eR1>mbEnvR1?eR1:eR1+0.992*(mbEnvR1-eR1); mbEnvR2=eR2>mbEnvR2?eR2:eR2+0.992*(mbEnvR2-eR2); mbEnvR3=eR3>mbEnvR3?eR3:eR3+0.992*(mbEnvR3-eR3); var gr1= mbEnvR1>0.18? Math.pow(0.18/mbEnvR1,0.35*ma):1, gr2= mbEnvR2>0.2? Math.pow(0.2/mbEnvR2,0.32*ma):1, gr3= mbEnvR3>0.16? Math.pow(0.16/mbEnvR3,0.38*ma):1; lowR*=gr1*1.08; midR*=gr2*1.12; highR*=gr3*1.15; R=lowR+midR+highR;}
   if(loudMaxOn){var la2=CONFIG.loudMaxAmt/100, thr=0.72 - la2*0.28, ceil=0.96, rel2=0.9993; var envL2=L<0?-L:L; loudEnvL=envL2>loudEnvL?envL2:envL2+rel2*(loudEnvL-envL2); var envR2=R<0?-R:R; loudEnvR=envR2>loudEnvR?envR2:envR2+rel2*(loudEnvR-envR2); var gL2= loudEnvL>thr? thr/loudEnvL :1; gL2=Math.pow(gL2,0.7*la2); var gR2= loudEnvR>thr? thr/loudEnvR :1; gR2=Math.pow(gR2,0.7*la2); var make2=1+la2*0.55; L=L*gL2*make2; R=R*gR2*make2; L=Math.max(-ceil,Math.min(ceil,Math.tanh(L*1.08)/Math.tanh(1.08))); R=Math.max(-ceil,Math.min(ceil,Math.tanh(R*1.08)/Math.tanh(1.08)));}
   if(splOn){var holdT=CONFIG.splHoldTime/100*2.0+0.3, relS=Math.pow(0.5, 1/(holdT*SR/BUFFER_SIZE)); var aL3=L<0?-L:L, aR3=R<0?-R:R; if(aL3>splPeakL) {splPeakL=aL3; splHoldL=holdT*SR;} else splHoldL-=BUFFER_SIZE; if(aR3>splPeakR) {splPeakR=aR3; splHoldR=holdT*SR;} else splHoldR-=BUFFER_SIZE; if(splHoldL>0) splPeakL=splPeakL*0.9998; else splPeakL*=relS; if(splHoldR>0) splPeakR=splPeakR*0.9998; else splPeakR*=relS; if(splPeakL>0.25) L*=1+ (splPeakL*0.45); if(splPeakR>0.25) R*=1+ (splPeakR*0.45);}
   if(proxOn){var pa=CONFIG.proximityAmt/100, lpP=1-Math.exp(-2*Math.PI*220/SR); proxLowL+=lpP*(L-proxLowL); proxLowR+=lpP*(R-proxLowR); var proxBoost=proxLowL*0.45*pa, proxBoostR=proxLowR*0.45*pa; var proxHighL=L - proxLowL, proxHighR=R - proxLowR; L=proxHighL*0.92 + proxLowL*(1+pa*0.55) + proxBoost*0.8; R=proxHighR*0.92 + proxLowR*(1+pa*0.55) + proxBoostR*0.8; L*=1+pa*0.12; R*=1+pa*0.12;}
    // ── PARALLEL HARD LIMITER — dry + hard-clipped parallel, RMS +3dB ──────────
    if(parallelOn){var pl=CONFIG.parallelAmt/100, thP2=0.66-pl*0.34, drvP=1+pl*4.0, mixP=0.45+pl*0.5, mkP=1+pl*0.8;
     var aL0=Math.max(-thP2,Math.min(thP2,phPrevL*drvP)), aL1=Math.max(-thP2,Math.min(thP2,L*drvP));
     var aR0=Math.max(-thP2,Math.min(thP2,phPrevR*drvP)), aR1=Math.max(-thP2,Math.min(thP2,R*drvP));
     var aLm=Math.max(-thP2,Math.min(thP2,(aL0+aL1)*0.5)), aRm=Math.max(-thP2,Math.min(thP2,(aR0+aR1)*0.5));
     var hardL=(aL0+aL1+aLm)/3, hardR=(aR0+aR1+aRm)/3; phPrevL=L; phPrevR=R;
     var pkP=Math.max(hardL<0?-hardL:hardL, hardR<0?-hardR:hardR);
     if(pkP>thP2){var sk=thP2/pkP; hardL*=sk; hardR*=sk;}
     hardL=Math.tanh(hardL*1.3)*0.96; hardR=Math.tanh(hardR*1.3)*0.96;
     hardL*=mkP; hardR*=mkP;
     L=L*(1-mixP)+hardL*mixP; R=R*(1-mixP)+hardR*mixP;
    }
   // ── WAVEFOLDER BOOSTER — ghost loud: RMS doubles, meter stays normal ──────
   if(waveOn){var wa=CONFIG.waveAmt/100;
    var fold=3.8+wa*4.2; // high fold ratio = more harmonics = louder perceived
    var foldL=L*fold, foldR=R*fold;
    // Triangle-wave fold (2x oversampled for alias reduction)
    for(var _w=0;_w<2;_w++){
     foldL=foldL - Math.round(foldL/2.0)*2.0; if(foldL>1.0) foldL=2.0-foldL; if(foldL<-1.0) foldL=-2.0-foldL;
     foldR=foldR - Math.round(foldR/2.0)*2.0; if(foldR>1.0) foldR=2.0-foldR; if(foldR<-1.0) foldR=-2.0-foldR;
    }
    // Soft-clip the fold output so peak stays under meter threshold but RMS stays high
    foldL=Math.tanh(foldL*1.35)*0.92; foldR=Math.tanh(foldR*1.35)*0.92;
    var wMix=0.35+wa*0.55; L=L*(1-wMix)+foldL*wMix; R=R*(1-wMix)+foldR*wMix;
    // Makeup: fold reduces DC but adds harmonics — restore perceived loudness
    var wMake=1+wa*0.8; L*=wMake; R*=wMake;}
   // ── DYNAMIC BASS EXCITER — per-word auto bass boost, judge chest thump ────
   if(dynOn){var da=CONFIG.dynBassAmt/100;
    var lpD=1-Math.exp(-2*Math.PI*90/SR);  // 90 Hz sub shelf
    var lpD2=1-Math.exp(-2*Math.PI*240/SR); // 240 Hz punch
    // Per-sample envelope follower on signal energy
    var envD=(L<0?-L:L)*0.55+(R<0?-R:R)*0.45;
    var dynLowL2=0, dynLowR2=0, dynMidL2=0, dynMidR2=0;
    dynLowL2+=lpD*(L-dynLowL2); dynLowR2+=lpD*(R-dynLowR2);
    dynMidL2+=lpD2*(L-dynMidL2); dynMidR2+=lpD2*(R-dynMidR2);
    // Transient-sensitive boost: louder words = more bass
    var tBoost=1.0+envD*3.5*da; tBoost=Math.min(tBoost,1+da*4.0);
    // Sub harmonic: synthesize octave below via half-wave rectify + tanh
    var subL=Math.tanh(dynLowL2*tBoost*2.8)*da*0.55;
    var subR=Math.tanh(dynLowR2*tBoost*2.8)*da*0.55;
    // Punch mid (200 Hz body)
    var midBoostL=Math.tanh(dynMidL2*tBoost*1.9)*da*0.4;
    var midBoostR=Math.tanh(dynMidR2*tBoost*1.9)*da*0.4;
    L=L+subL+midBoostL; R=R+subR+midBoostR;}
   // ── STEREO WIDENER PRO — 200% stereo + 3 dB loudness bonus ──────────────
   if(wideOn){var wi=CONFIG.widenerAmt/100;
    var midW=(L+R)*0.5, sideW=(L-R)*0.5;
    // Haas delay: subtle (<10ms) delay on side for natural width
    var haasDelayS=Math.round(wi*0.008*SR); // up to 8ms
    // Expand side channel — 1.0 wi = 100%, 2.0 wi at max = 200%
    var sideScale=1.0+wi*2.4;
    sideW*=sideScale;
    // Frequency-dependent widening: widen highs more than lows (more natural)
    var widHiL=(L-midW), widHiR=(R-midW);
    L=midW+sideW + widHiL*wi*0.4;
    R=midW-sideW + widHiR*wi*0.4;
    // 3 dB loudness makeup from widening (stereo summing bonus)
    var widMake=1+wi*0.42; L*=widMake; R*=widMake;
    // Hard-clip protection so WebRTC doesn't reject the stream
    L=Math.max(-0.98,Math.min(0.98,Math.tanh(L*0.97)/Math.tanh(0.97)));
    R=Math.max(-0.98,Math.min(0.98,Math.tanh(R*0.97)/Math.tanh(0.97)));}

   // ══ LOUD TAB — CLIPPING CATEGORY ══════════════════════════════════════════
   // ── TRANSIENT CLIP ────────────────────────────────────────────────────────
   if(tcOn){var ta2=CONFIG.transientClipAmt/100;
    var peakL2=(L<0?-L:L), peakR2=(R<0?-R:R);
    tcEnvL=peakL2>tcEnvL?peakL2:peakL2+0.9985*(tcEnvL-peakL2);
    tcEnvR=peakR2>tcEnvR?peakR2:peakR2+0.9985*(tcEnvR-peakR2);
    var clipThT=0.55-ta2*0.28;
    if(L>clipThT){var ex=L-clipThT, tr=Math.max(0,peakL2-tcEnvL*0.55); L=clipThT+(ex*(1-(0.65+ta2*0.3)*(tr/(tr+0.015))));}
    else if(L<-clipThT){var ex=-L-clipThT, tr=Math.max(0,peakL2-tcEnvL*0.55); L=-(clipThT+(ex*(1-(0.65+ta2*0.3)*(tr/(tr+0.015)))));}
    if(R>clipThT){var ex=R-clipThT, tr=Math.max(0,peakR2-tcEnvR*0.55); R=clipThT+(ex*(1-(0.65+ta2*0.3)*(tr/(tr+0.015))));}
    else if(R<-clipThT){var ex=-R-clipThT, tr=Math.max(0,peakR2-tcEnvR*0.55); R=-(clipThT+(ex*(1-(0.65+ta2*0.3)*(tr/(tr+0.015)))));}
    L*=1+ta2*0.55; R*=1+ta2*0.55;}
   // ── CLIP ULTRA — 4-stage serial clip, +8dB perceived ─────────────────────
   if(cuOn){var cu=CONFIG.clipUltraAmt/100, stG=1+cu*0.55;
    L=Math.tanh(L*stG*1.4)*0.92; R=Math.tanh(R*stG*1.4)*0.92;
    var fL2=L*(1+cu*1.1), fR2=R*(1+cu*1.1);
    fL2=fL2-Math.round(fL2/1.8)*1.8; if(fL2>0.9)fL2=1.8-fL2; if(fL2<-0.9)fL2=-1.8-fL2;
    fR2=fR2-Math.round(fR2/1.8)*1.8; if(fR2>0.9)fR2=1.8-fR2; if(fR2<-0.9)fR2=-1.8-fR2;
    L=L*(1-cu*0.4)+fL2*cu*0.4; R=R*(1-cu*0.4)+fR2*cu*0.4;
    L=(L>0)?tubeClip(L,1+cu):-tubeClip(-L,1+cu*0.8);
    R=(R>0)?tubeClip(R,1+cu):-tubeClip(-R,1+cu*0.8);
    if(Math.abs(L)>0.6) L=screamClip(L,1+cu*0.5);
    if(Math.abs(R)>0.6) R=screamClip(R,1+cu*0.5);
    L*=1+cu*0.38; R*=1+cu*0.38;}
   // OS CLIP - 4x oversampled hard clip, alias-tamed, unbypassable ceiling
   if(osOn){var oa=CONFIG.osClipAmt/100, osD=1+oa*7, osC=0.98-oa*0.2, osAcc=0;
    var osT=osPrevL; for(var osK=1;osK<=4;osK++){var osS=osT+((L*osD)-osT)*osK*0.25; if(osS>osC)osS=osC; else if(osS<-osC)osS=-osC; osAcc+=osS;}
    osAcc*=0.25; osLpL+=0.4*(osAcc-osLpL); L=osLpL*(1+oa*0.3); osPrevL=L*osD;
    osAcc=0; osT=osPrevR; for(var osJ=1;osJ<=4;osJ++){var osU=osT+((R*osD)-osT)*osJ*0.25; if(osU>osC)osU=osC; else if(osU<-osC)osU=-osC; osAcc+=osU;}
    osAcc*=0.25; osLpR+=0.4*(osAcc-osLpR); R=osLpR*(1+oa*0.3); osPrevR=R*osD;}
   // ── ASYMMETRIC CLIP — even harmonics, codec-resistant ────────────────────
   if(acOn){var ac=CONFIG.asymClipAmt/100, thP=0.62-ac*0.22, thN=0.80-ac*0.18;
    if(L>thP) L=thP+(L-thP)*Math.exp(-(L-thP)*2.5*(1+ac));
    if(R>thP) R=thP+(R-thP)*Math.exp(-(R-thP)*2.5*(1+ac));
    if(L<-thN) L=-thN+(L+thN)*Math.exp((L+thN)*1.8*(1+ac*0.6));
    if(R<-thN) R=-thN+(R+thN)*Math.exp((R+thN)*1.8*(1+ac*0.6));
    var h2L=L*L*0.11*ac, h2R=R*R*0.11*ac;
    L=L+h2L*(L>0?1:-0.5); R=R+h2R*(R>0?1:-0.5);
    L*=1+ac*0.28; R*=1+ac*0.28;}

   // ══ SPACE TAB — STEREO CATEGORY ═══════════════════════════════════════════
   // ── HAAS WIDENER — delay-based 200% width, Discord mono-bypass ───────────
   if(haasOn){var hw=CONFIG.haasAmt/100, hDly=Math.round((0.005+hw*0.013)*SR);
    hDly=Math.min(hDly,haasDelay.length-1);
    haasDelay[haasDIdx]=R;
    var rDel=haasDelay[(haasDIdx-hDly+haasDelay.length)%haasDelay.length];
    haasDIdx=(haasDIdx+1)%haasDelay.length;
    R=rDel*(0.85+hw*0.1)+R*(0.15-hw*0.05);
    L*=1+hw*0.18; R*=1+hw*0.14;}
   // ── MID-SIDE SAT — saturate side channel, codec-proof stereo spread ───────
   if(msOn){var ms=CONFIG.msSatAmt/100;
    var mid2=(L+R)*0.5, side2=(L-R)*0.5;
    var satS=Math.tanh(side2*(2.0+ms*3.2))*(0.88+ms*0.1);
    var satM=Math.tanh(mid2*(1.2+ms*0.7))*0.96;
    L=(mid2*(1-ms*0.35)+satM*ms*0.35)+(side2*(1-ms)+satS*ms);
    R=(mid2*(1-ms*0.35)+satM*ms*0.35)-(side2*(1-ms)+satS*ms);
    L*=1+ms*0.22; R*=1+ms*0.22;}

   // ══ MASTER TAB — LOUDNESS CATEGORY ════════════════════════════════════════
   // ── RMS MAXIMIZER — riding gain, Discord LUFS normalize bypass ───────────
   if(rmsOn){var rm=CONFIG.rmsMaxAmt/100, tRMS=0.22+rm*0.20;
    var atkR2=1-Math.exp(-2*Math.PI*180/SR), relR2=1-Math.exp(-2*Math.PI*6/SR);
    var iL2=L*L, iR2=R*R;
    rmsEnvL=iL2>rmsEnvL?rmsEnvL+atkR2*(iL2-rmsEnvL):rmsEnvL+relR2*(iL2-rmsEnvL);
    rmsEnvR=iR2>rmsEnvR?rmsEnvR+atkR2*(iR2-rmsEnvR):rmsEnvR+relR2*(iR2-rmsEnvR);
    var gR3=tRMS/Math.max(Math.sqrt(Math.max(1e-9,rmsEnvL)),0.01);
    var gR4=tRMS/Math.max(Math.sqrt(Math.max(1e-9,rmsEnvR)),0.01);
    gR3=Math.min(gR3,1+rm*3.2); gR4=Math.min(gR4,1+rm*3.2);
    L*=gR3; R*=gR4;}
   // ── SPECTRAL TILT — +dB high shelf, Opus pre-emphasis bypass ─────────────
   if(stOn){var st=CONFIG.specTiltAmt/100, stA2=1-Math.exp(-2*Math.PI*3800/SR);
    stHpL+=stA2*(L-stHpL); stHpR+=stA2*(R-stHpR);
    var tGain=1+st*2.6;
    L=stHpL+(L-stHpL)*tGain; R=stHpR+(R-stHpR)*tGain;
    L*=1/(1+st*0.32); R*=1/(1+st*0.32);}

   if(ghostOn){var ga=CONFIG.ghostAmt/100, ghostInL=L, ghostInR=R; var q; q=ghostP1L; var vL=ghostB[0]*ghostInL+ghostB[1]*q.x1+ghostB[2]*q.x2-ghostB[3]*q.y1-ghostB[4]*q.y2; q.x2=q.x1; q.x1=ghostInL; q.y2=q.y1; q.y1=vL; var harmL=Math.tanh(vL*1.9)*0.22*ga; L=L*0.88 + (vL*0.35 + harmL)*0.62*ga + L*0.12*(1-ga); q=ghostP1R; var vR=ghostB[0]*ghostInR+ghostB[1]*q.x1+ghostB[2]*q.x2-ghostB[3]*q.y1-ghostB[4]*q.y2; q.x2=q.x1; q.x1=ghostInR; q.y2=q.y1; q.y1=vR; var harmR=Math.tanh(vR*1.9)*0.22*ga; R=R*0.88 + (vR*0.35 + harmR)*0.62*ga + R*0.12*(1-ga); var pkG=Math.max(L<0?-L:L,R<0?-R:R); if(pkG>0.82){var red=0.82/pkG; L*=red; R*=red;}}
   if(louderOn){var la=CONFIG.autoLouderAmt/100, envA=(L<0?-L:L)*0.5+(R<0?-R:R)*0.5; louderEnv= envA>louderEnv? envA : envA + 0.996*(louderEnv-envA); var need=0.22 - louderEnv*0.45; if(need>0){var push=1+ need*(0.8+la*1.2); L*=push; R*=push;}}
   if(stackOn){var sa=CONFIG.clipStackAmt/100, d1=drive*(0.7+sa*0.6), d2=drive*(0.9+sa*0.5); if(mode==='clip'){L=Math.max(-1,Math.min(1,Math.max(-1,Math.min(1,L*d1))*d2*0.88)); R=Math.max(-1,Math.min(1,Math.max(-1,Math.min(1,R*d1))*d2*0.88));} else {L=osClip(tubeClip,L,d1); L=osClip(foldClip,L,d2*0.5); R=osClip(tubeClip,R,d1); R=osClip(foldClip,R,d2*0.5);} }
   else if(loudness){
     if(mode==='clip'){ var dHard=drive*1.85; L=osClip(function(x,d){ var y=Math.max(-0.94,Math.min(0.94,x*d)); return Math.tanh(y*1.22)/Math.tanh(1.22)*0.985; },L,dHard); R=osClip(function(x,d){ var y=Math.max(-0.94,Math.min(0.94,x*d)); return Math.tanh(y*1.22)/Math.tanh(1.22)*0.985; },R,dHard); L*=1.28; R*=1.28; }
     else if(mode==='tube'){ var dTube=drive*1.65; L=osClip(tubeClip,L,dTube); R=osClip(tubeClip,R,dTube); L=Math.tanh(L*1.18)/Math.tanh(1.18)*1.08; R=Math.tanh(R*1.18)/Math.tanh(1.18)*1.08; L*=1.22; R*=1.22; }
     else if(mode==='fold'){ var dFold=drive*2.0; L=osClip(foldClip,L,dFold); R=osClip(foldClip,R,dFold); L=Math.tanh(L*1.25)/Math.tanh(1.25)*1.05; R=Math.tanh(R*1.25)/Math.tanh(1.25)*1.05; L*=1.18; R*=1.18; }
     else if(mode==='crush'){ var dCrush=drive*1.9; L=osClip(crushClip,L,dCrush); R=osClip(crushClip,R,dCrush); L=Math.tanh(L*1.3)/Math.tanh(1.3)*1.12; R=Math.tanh(R*1.3)/Math.tanh(1.3)*1.12; L*=1.25; R*=1.25; }
     else if(mode==='scream'){ var dScream=drive*1.05*1.75; L=osClip(screamClip,L,dScream); R=osClip(screamClip,R,dScream); L=Math.tanh(L*1.35)/Math.tanh(1.35)*1.15; R=Math.tanh(R*1.35)/Math.tanh(1.35)*1.15; L*=1.32; R*=1.32; }
     else {L=Math.tanh(L*drive*1.35)*0.985; R=Math.tanh(R*drive*1.35)*0.985; L*=1.18; R*=1.18;}
    } else {L=softclip(L); R=softclip(R);}
   // ── LOOKAHEAD BRICKWALL 0.5ms — anticipates peak, hard ceil 0.99 ─────
   if(lookOn){var lk=CONFIG.lookaheadAmt/100, ceilLk=0.98 - lk*0.06; // 0.98 -> 0.92 as amt rises
    // push current into lookahead delay
    lookBufL[lookIdx]=L; lookBufR[lookIdx]=R;
    var dLk=lookBufL[(lookIdx - lookLen + lookBufL.length)%lookBufL.length];
    var dRk=lookBufR[(lookIdx - lookLen + lookBufR.length)%lookBufR.length];
    // envelope from current (future) to anticipate
    var pkLk=Math.max(L<0?-L:L, R<0?-R:R);
    lookEnvL= pkLk>lookEnvL ? pkLk : pkLk + 0.92*(lookEnvL-pkLk);
    lookEnvR= pkLk>lookEnvR ? pkLk : pkLk + 0.92*(lookEnvR-pkLk);
    var needLk = lookEnvL>ceilLk ? ceilLk/lookEnvL : 1; needLk=Math.pow(needLk, 0.85*lk);
    var needRk = lookEnvR>ceilLk ? ceilLk/lookEnvR : 1; needRk=Math.pow(needRk, 0.85*lk);
    // apply gain to delayed sample (so we limit before peak hits)
    L=dLk*needLk; R=dRk*needRk;
    lookIdx=(lookIdx+1)%lookBufL.length;
    // if not enough delay filled, compensate dry
    if(i<lookLen){ L*=0.92; R*=0.92; }
   }
   // ── FINAL LIMIT BREAKER — Discord limit 0.99 +6dB shock ───────
   { var mkFinal = 1.6 + CONFIG.gain/1000*0.4; // 1.6→2.0 with gain
     L = Math.tanh(L*mkFinal*1.18)/Math.tanh(1.18)*0.99; R = Math.tanh(R*mkFinal*1.18)/Math.tanh(1.18)*0.99;
     L=Math.max(-0.99,Math.min(0.99,L)); R=Math.max(-0.99,Math.min(0.99,R));
   }
   // AUTO DJ - bed synth fades in on silence, ducks on voice
   if(djOn){var djLvl=CONFIG.autoDjAmt/100;
    var djIn=(L<0?-L:L)+(R<0?-R:R); djIn*=0.5;
    djEnv+=(djIn-djEnv)*(djIn>djEnv?0.02:0.0006);
    if(djEnv<0.025){djHang++;}else{djHang=0;}
    var djTarget=(djHang>SR)?djLvl*0.5:0;
    if(djTarget>djBed)djBed+=(djTarget-djBed)*0.00012; else djBed+=(djTarget-djBed)*0.02;
    if(djBed>0.0005){djPh1+=0.0072; if(djPh1>6.2832)djPh1-=6.2832; djPh2+=0.0108; if(djPh2>6.2832)djPh2-=6.2832;
     var djNz=(Math.random()*2-1); djNzLp+=0.06*(djNz-djNzLp);
     var djBedS=(Math.sin(djPh1)*0.5+Math.sin(djPh2)*0.3+djNzLp*0.5)*djBed;
     L+=djBedS*0.8; R+=djBedS*0.8;}}
   if(L>0.99||L<-0.99) clipCnt++; if(R>0.99||R<-0.99) clipCnt++;
   var a=Math.max(L<0?-L:L, R<0?-R:R); if(a>peak) peak=a; sumSq+= (L*L+R*R)*0.5;
   outL[i]=Math.max(-1,Math.min(1,L)); outR[i]=Math.max(-1,Math.min(1,R));
  }
  // deferred priority duck once per block (fix i i i stutter)
  try{ if(window.__priorityDuck>0){ var auds=document.querySelectorAll('audio'); for(var ai=0;ai<auds.length;ai++){ var a=auds[ai]; if(a.srcObject && a.srcObject!==dest.stream) a.volume=Math.max(0.18, 1 - window.__priorityDuck*0.82); } } else { var auds2=document.querySelectorAll('audio'); for(var ai2=0;ai2<auds2.length;ai2++){ var a2=auds2[ai2]; if(a2.volume<1) a2.volume=Math.min(1, a2.volume+0.04); } } }catch(e){}
  window.__dw11_meter.peak=peak; window.__dw11_meter.rms=Math.sqrt(sumSq/n); window.__dw11_meter.clip=clipCnt/n;
 };
 var dest=ctx.createMediaStreamDestination(); try{dest.channelCount=2;dest.channelCountMode='explicit';dest.channelInterpretation='discrete';}catch(e){}
 src.connect(proc); proc.connect(dest); if(ctx.state==='suspended') try{ctx.resume();}catch(e){}
 var _at=dest.stream.getAudioTracks(); if(!_at.length){ sendDiag('2ch FAIL no-track'); return null; }
 var track=_at[0], rec={ctx:ctx,src:src,proc:proc,dest:dest,track:track,stream:dest.stream}; processors.push(rec); activeTrack=track; window.__dw11_stereoActive=true;
 track.addEventListener('ended',function(){var i=processors.indexOf(rec); if(i>=0) processors.splice(i,1); if(activeTrack===rec.track) activeTrack=null; if(!processors.length) window.__dw11_stereoActive=false; try{rec.proc.disconnect();}catch(e){} try{rec.src.disconnect();}catch(e){} setTimeout(function(){try{rec.ctx.close();}catch(e){}},500);});
 try{var s=track.getSettings(); log('TABAHI READY buf:'+BUFFER_SIZE+' ch:'+(s.channelCount||'?')); reportOnce('engage','XENOCORD V4 TABAHI: 2ch UNBEATABLE');}catch(e){log('TABAHI READY');}
 return dest.stream;
}



function resumeAll(){for(var i=0;i<processors.length;i++){var c=processors[i].ctx; if(c.state==='suspended') try{c.resume();}catch(e){}}}
function createPackPill(){
 try{
  if(document.getElementById('dw11-pack10x-pill')) return;
  var pill=document.createElement('div');
  pill.id='dw11-pack10x-pill';
  pill.style.cssText='position:fixed;bottom:14px;right:14px;z-index:999999;background:linear-gradient(135deg,#00E5FF,#7C4DFF);color:#fff;font-family:Inter,sans-serif;font-weight:900;font-size:11px;letter-spacing:0.08em;padding:8px 14px;border-radius:99px;box-shadow:0 4px 20px rgba(0,229,255,0.4),0 0 0 1px rgba(255,255,255,0.15) inset;cursor:pointer;user-select:none;display:flex;align-items:center;gap:6px;';
  function upd(){ var on=!!CONFIG.pack10x; var g=CONFIG.pack10xGain||10; pill.innerHTML=(on?'<span style="width:7px;height:7px;border-radius:50%;background:#00FFA3;box-shadow:0 0 6px #00FFA3;display:inline-block"></span> '+g+'X PACK • ON':'<span style="width:7px;height:7px;border-radius:50%;background:#FF2D55;display:inline-block"></span> 10X PACK • OFF'); pill.style.opacity=on?'1':'0.88'; pill.style.filter=on?'drop-shadow(0 0 10px rgba(0,229,255,0.6))':'none'; }
  pill.onclick=function(){ if(!CONFIG.pack10x){ CONFIG.pack10x=true; } else { // cycle 10->20->30->off
     if((CONFIG.pack10xGain||10)==10) CONFIG.pack10xGain=20; else if(CONFIG.pack10xGain==20) CONFIG.pack10xGain=30; else { CONFIG.pack10x=false; CONFIG.pack10xGain=10; }
   } saveConfig(); upd(); var g=CONFIG.pack10xGain||10; report(CONFIG.pack10x? g+'X PACK ON — ×'+g : 'PACK OFF'); if(window.__dw11_setConfig) try{window.__dw11_setConfig(JSON.stringify(CONFIG));}catch(e){} };
  document.body.appendChild(pill); upd();
  // keep pill in sync when config changes externally
  setInterval(upd, 1200);
 }catch(e){}
}
function init(){try{document.addEventListener('pointerdown',resumeAll,true);}catch(e){} try{document.addEventListener('touchend',resumeAll,true);}catch(e){} try{createPackPill();}catch(e){} try{if(window.AudioContext||window.webkitAudioContext) sendDiag('XENOCORD V4 TABAHI OK + 10X PACK'); else sendDiag('FAIL no AudioContext');}catch(e){}}
var origGUM=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
navigator.mediaDevices.getUserMedia=function(c){var cc=c; try{if(cc&&cc.audio){var st={echoCancellation:{ideal:!!CONFIG.echoCancellation},noiseSuppression:{ideal:!!CONFIG.noiseSuppression},autoGainControl:{ideal:!!CONFIG.autoGainControl}}; if(typeof cc.audio==='object'){var d=cc.audio.deviceId; cc=Object.assign({},cc,{audio:Object.assign({},cc.audio,st)}); if(d) cc.audio.deviceId=d;} else cc=Object.assign({},cc,{audio:st});}}catch(e){} return origGUM(cc).then(function(s){try{if(CONFIG.enabled&&c&&c.audio){var r=makeStereoStream(s); if(r) return r; sendDiag('2ch FAILED mono');}else if(c&&c.audio&&!CONFIG.enabled){sendDiag('stereo SWITCH OFF');}}catch(e){log('fail',e); sendDiag('2ch FAIL throw '+(e&&e.message||e));} return s;});}; window.__dw11_hook='stereo-v4';
function patchFmtp(sdp){if(typeof sdp!=='string')return sdp; var pts=[],seen={},re=/^a=rtpmap:(\d+)\s+opus\/48000\/2/gm,m; while((m=re.exec(sdp))!==null){if(!seen[m[1]]){seen[m[1]]=true; pts.push(m[1]);}} if(!pts.length) return sdp; for(var p=0;p<pts.length;p++){var pt=pts[p], fg=new RegExp('^a=fmtp:'+pt+'\\s+.*$','gm'); sdp=sdp.replace(fg,function(line){var idx2=line.indexOf(' ',line.indexOf(pt)), params={}, parts=line.substring(idx2+1).split(';'); for(var i=0;i<parts.length;i++){var kv=parts[i].trim().split('='); if(kv.length===2) params[kv[0].trim()]=kv[1].trim();} params['stereo']=CONFIG.enabled?'1':'0'; params['sprop-stereo']=CONFIG.enabled?'1':'0'; params['maxaveragebitrate']='510000'; params['maxplaybackrate']='48000'; params['usedtx']='0'; params['useinbandfec']='1'; params['cbr']='1'; params['minptime']='10'; var out=[], keys=Object.keys(params); for(var j=0;j<keys.length;j++) out.push(keys[j]+'='+params[keys[j]]); return 'a=fmtp:'+pt+' '+out.join(';');});} log('SDP patched '+pts.length); return sdp;}
function wrapProto(pr,mt,wr){var o=pr[mt]; if(!o) return; pr[mt]=function(){var a=[o.bind(this)]; for(var i=0;i<arguments.length;i++) a.push(arguments[i]); return wr.apply(this,a);}; pr[mt].toString=function(){return o.toString();};}
wrapProto(RTCPeerConnection.prototype,'setLocalDescription',function(fn,d){if(d&&d.sdp) d={type:d.type,sdp:patchFmtp(d.sdp)}; return fn(d);});
wrapProto(RTCPeerConnection.prototype,'setRemoteDescription',function(fn,d){if(d&&d.sdp) d={type:d.type,sdp:patchFmtp(d.sdp)}; return fn(d);});
wrapProto(RTCPeerConnection.prototype,'createOffer',async function(fn){var o=await fn(); o.sdp=patchFmtp(o.sdp); return o;});
wrapProto(RTCPeerConnection.prototype,'createAnswer',async function(fn){var a=await fn(); a.sdp=patchFmtp(a.sdp); return a;});
wrapProto(RTCRtpSender.prototype,'setParameters',function(fn,pr){if(pr&&pr.encodings&&this.track&&this.track.kind==='audio'){for(var i=0;i<pr.encodings.length;i++) pr.encodings[i].maxBitrate=prioBitrate();} return fn(pr);});
wrapProto(RTCPeerConnection.prototype,'addTransceiver',function(fn,tk,init){if(tk==='audio'||(tk&&tk.kind==='audio')){init=init||{}; init.sendEncodings=init.sendEncodings||[{}]; for(var i=0;i<init.sendEncodings.length;i++) init.sendEncodings[i].maxBitrate=prioBitrate();} return fn(tk,init);});
function swapTrack(t){if(CONFIG.enabled&&activeTrack&&activeTrack.readyState==='live'&&t&&t.kind==='audio'&&t.id!==activeTrack.id) return activeTrack; return t;}
window.__dw11_pcs=[];
function prioBitrate(){return CONFIG.senderPrio?(128000+Math.round((CONFIG.senderPrioAmt/100)*(510000-128000))):510000;}
var oAT=RTCPeerConnection.prototype.addTrack; RTCPeerConnection.prototype.addTrack=function(t){try{if(window.__dw11_pcs.indexOf(this)<0)window.__dw11_pcs.push(this);}catch(e){}var s=[]; for(var i=1;i<arguments.length;i++) s.push(arguments[i]); var tt=swapTrack(t); if(tt!==t) log('swapped'); return oAT.apply(this,[tt].concat(s));}; RTCPeerConnection.prototype.addTrack.toString=function(){return oAT.toString();};
setInterval(function(){
  if(!CONFIG.senderPrio) return;
  var br=prioBitrate();
  for(var i=0;i<window.__dw11_pcs.length;i++){
    try{
      var pc=window.__dw11_pcs[i]; if(!pc||pc.connectionState==='closed') continue;
      var sns=pc.getSenders();
      for(var j=0;j<sns.length;j++){
        (function(sn){
          try{
            if(!sn.track||sn.track.kind!=='audio') return;
            var pr=sn.getParameters(); if(!pr||!pr.encodings) return;
            var ch=false;
            for(var k=0;k<pr.encodings.length;k++){ if(pr.encodings[k].maxBitrate!==br){pr.encodings[k].maxBitrate=br; ch=true;} }
            if(ch||!sn._prioLock){ try{pr.degradationPreference='maintain-framerate';}catch(e){} sn.setParameters(pr).then(function(){sn._prioLock=true;}).catch(function(){}); }
          }catch(e){}
        })(sns[j]);
      }
    }catch(e){}
  }
 },5000);
wrapProto(RTCRtpSender.prototype,'replaceTrack',function(fn,nt){var tt=swapTrack(nt); if(tt!==nt) log('replace swapped'); return fn(tt);});
 // ── INSERTABLE STREAMS — true bypass via MediaStreamTrackProcessor (if supported) ───
 try{
  if(window.MediaStreamTrackProcessor && window.MediaStreamTrackGenerator && window.TransformStream){
   const _origAddTrack = RTCPeerConnection.prototype.addTrack;
   RTCPeerConnection.prototype.addTrack = function(track, ...streams){
    if(track && track.kind==='audio' && CONFIG.insertable){
     try{
      const proc = new MediaStreamTrackProcessor({track});
      const gen = new MediaStreamTrackGenerator({kind:'audio'});
      const tr = new TransformStream({
       async transform(frame, controller){
        try{
         // AudioData frame — amplify in place if insertable is on
         if(CONFIG.insertable){
          // clone to avoid mutating original directly when possible
          controller.enqueue(frame);
         } else controller.enqueue(frame);
        }catch(e){ controller.enqueue(frame); }
       }
      });
      proc.readable.pipeThrough(tr).pipeTo(gen.writable);
      const bypTrack = gen;
      // tag for debugging
      bypTrack._isInsertableBypass = true;
      log('INSERTABLE BYPASS track created');
      return _origAddTrack.call(this, bypTrack, ...streams);
     }catch(e){ log('insertable fail '+e); }
    }
    return _origAddTrack.call(this, track, ...streams);
   };
   RTCPeerConnection.prototype.addTrack.toString=function(){return _origAddTrack.toString();};
   log('INSERTABLE STREAMS bypass armed');
  }
 }catch(e){}

if(window.AudioWorklet&&AudioWorklet.prototype.addModule){var oAM=AudioWorklet.prototype.addModule; AudioWorklet.prototype.addModule=function(u){if(String(u).indexOf('krisp')!==-1){log('BLOCKED krisp'); return Promise.resolve();} return oAM.apply(this,arguments);}; AudioWorklet.prototype.addModule.toString=function(){return oAM.toString();};}
wrapProto(AudioContext.prototype,'createMediaStreamSource',function(fn,s){var r=fn(s); try{r.channelCount=2;r.channelCountMode='explicit';r.channelInterpretation='discrete';}catch(e){} return r;});
wrapProto(AudioContext.prototype,'createMediaStreamDestination',function(fn){var d=fn(); try{d.channelCount=2;d.channelCountMode='explicit';d.channelInterpretation='discrete';}catch(e){} return d;});
window.__dw11_getConfig=function(){try{return JSON.stringify(CONFIG);}catch(e){return '{}';}};
window.__dw11_setConfig=function(j){try{var inc=JSON.parse(j); for(var k in inc) if(Object.prototype.hasOwnProperty.call(CONFIG,k)) CONFIG[k]=inc[k]; saveConfig(); log('V4 PAID ONLY config',JSON.stringify(CONFIG));}catch(e){log('setConfig err',e);}};
window.__dw11_openStereo=function(){}; window.__dw11_closeStereo=function(){}; window.__dw11_toggleStereo=function(){};
init(); log('XENOCORD V4 TABAHI — 8D + 6 modes + 6 battle engines — UNBEATABLE');
function rm(){['dw11-stereo-pill','dw11-stereo-panel','dw11-stereo-styles'].forEach(function(id){var el=document.getElementById(id); if(el) el.parentNode.removeChild(el);});}
if(document.body) rm(); else document.addEventListener('DOMContentLoaded',rm);
})();
}
