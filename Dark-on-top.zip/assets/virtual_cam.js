(function () {
    'use strict';
    if (window.__virtualCamInjected) return;
    window.__virtualCamInjected = true;

    let virtualStream = null;
    let videoElement = null;
    window.__virtualCamActive = false;

    window.__setVirtualVideo = function (file) {
        try {
            const url = URL.createObjectURL(file);
            if (!videoElement) {
                videoElement = document.createElement('video');
                videoElement.loop = true;
                videoElement.muted = true;
                videoElement.playsInline = true;
                videoElement.crossOrigin = 'anonymous';
                videoElement.style.display = 'none';
                document.body.appendChild(videoElement);
            }
            videoElement.src = url;
            videoElement.play().then(() => {
                if (videoElement.captureStream) {
                    virtualStream = videoElement.captureStream();
                } else if (videoElement.mozCaptureStream) {
                    virtualStream = videoElement.mozCaptureStream();
                }
                console.log("[DarkAlise VirtualCam] Video stream loaded successfully.");
            }).catch(err => {
                console.error("[DarkAlise VirtualCam] Play error:", err);
            });
        } catch (e) {
            console.error("[DarkAlise VirtualCam] setVirtualVideo error:", e);
        }
    };

    window.__toggleVirtualCam = function (enabled) {
        window.__virtualCamActive = !!enabled;
        console.log("[DarkAlise VirtualCam] Active:", window.__virtualCamActive);
    };

    const origGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async function (constraints) {
        let stream;
        try {
            stream = await origGUM(constraints);
        } catch (e) {
            throw e;
        }
        try {
            if (window.__virtualCamActive && virtualStream && constraints && constraints.video) {
                const videoTrack = virtualStream.getVideoTracks()[0];
                if (videoTrack) {
                    const tracks = stream.getVideoTracks();
                    for (let t of tracks) {
                        try { t.stop(); } catch(err){}
                        stream.removeTrack(t);
                    }
                    stream.addTrack(videoTrack);
                    console.log("[DarkAlise VirtualCam] Camera track successfully replaced with uploaded video.");
                }
            }
        } catch (e) {
            console.error("[DarkAlise VirtualCam] Track replacement error:", e);
        }
        return stream;
    };
})();
